﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using Oracle.DataAccess.Client;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Globalization;
using ICSharpCode.SharpZipLib.Zip;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.Data.SqlClient;
using NACH.StateClass;
using NACH.BLL;
using NACH_Application;
using System.IO.Compression;
using Impersonator;
using System.Drawing.Imaging;
//using System.IO.Compression.FileSystem;


public partial class Register_Mandate_UploadImageData : System.Web.UI.Page
{

    public UploadImageDataSC Doc { get; set; }
    UserObj mUserObj = new UserObj();
    cls_DBConnection objDb = new cls_DBConnection();  //added rutuja 25/07/2019
    string m_QryStr;
    string m_EndBatch, m_inwdate;
    int m_StartBatch;
    string m_path, m_ImgName, M_Reason, m_CollType;
    int m_ImgCount, m_Batch, M_PouchFrom, M_PouchTo, M_MaxPouchFrom, M_MaxPouchTo;
    int K, M_MaxCount, M_AMOUNT;
    Boolean m_Flag, m_InsertFlag, m_ImageFlag;
    Excel.Application xlsApp;
    Excel.Workbook xlsBook;
    Excel.Worksheet xlsSheet;
    DataSet ds1;
    StreamWriter StrWrt, SW;
    OracleTransaction TRANS;  //added rutuja 25/07/2019
    string[] m_AllJpeg;
    string[] m_tiff;
    string[] m_jpeg;
    string[] m_MatchImage;
    int m_jpgCnt, m_tifCnt;
    string m_FlNm;
    bool m_JpegFlag, m_TiffFlag;
    Boolean m_JpgFlag, m_TifFlag;
    string m_jpgName;
    string[] M_Jpgcount;
    int m_BatchCount;
    string temp, temp1;
    string tmpZip;
    Boolean M_StartFlag;
    float hres, vres;  //Added by rutuja
    string Line;

    

    string ImagePath = string.Empty;  //added by rutuja

    private Boolean IsPageRefresh = false;
    static int m_Srno = 0;
    bool ValidZip = true;
    int RejCount;   //added by rutuja for file compress on 25/07/2019

    //string[] imagenottomove;

    List<string> imagenottomove = new List<string>();

    List<string> movefile = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            InitDoc();
            if (!Page.IsPostBack)
            {



                if (cls_General.GL_NPCIBankCd == "SYNB" || cls_General.GL_NPCIBankCd == "CNSX" || cls_General.GL_NPCIBankCd == "ORBC" || cls_General.GL_NPCIBankCd == "PGBX" || cls_General.GL_NPCIBankCd == "KLGB" || cls_General.GL_NPCIBankCd == "JSAB" || cls_General.GL_NPCIBankCd == "KODX" || cls_General.GL_NPCIBankCd == "RATN" || cls_General.GL_NPCIBankCd == "USFB" || cls_General.GL_NPCIBankCd == "UBIN")
                {
                   
                    chkfb.Visible = true;
                   // chkfb.Checked = false;
                    lblScanner.Visible = true;
                    //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- At Page load :" + cls_General.GL_NPCIBankCd + "UBIN" + "\r\n");

                    
                }
                else
                {
                    chkfb.Visible = false;
                    chkfb.Checked = false;
                    lblScanner.Visible = false;
                }

                //chkfb.Visible = false;
                //chkfb.Checked = false;                    
                linkExcel.Visible = false;
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.linkExcel);
                flUpld.BackColor = flUpldManData.BackColor = Color.White;
                chkManData.Enabled = false;
                flUpldManData.Enabled = false;
               // chkfb.Checked = true;

                if (this.Session["FileUpload1"] == null && flUpld.HasFile)
                {
                    this.Session["FileUpload1"] = flUpld;
                }
                else if (this.Session["FileUpload1"] != null && flUpld.HasFile)
                {
                    flUpld = (FileUpload)this.Session["FileUpload1"];
                }
                else if (flUpld.HasFile)
                {
                    this.Session["FileUpload1"] = flUpld;
                }

                chkManData.Visible = flUpldManData.Visible = lblMsg.Visible = false;

                //------- After Uploading File, Refreshing Page causes file to upload again 
                //---So below prevent it ------- 
                ViewState["postids"] = System.Guid.NewGuid().ToString();
                Session["postid"] = ViewState["postids"].ToString();

                lblSoleId.Visible = txtSolId.Visible = lblinwdate.Visible = txtinwdate.Visible = false;

            }
            else
            {
                if (ViewState["postids"].ToString() != Session["postid"].ToString())
                {
                    IsPageRefresh = true;
                }
                Session["postid"] = System.Guid.NewGuid().ToString();
                ViewState["postids"] = Session["postid"];
            }
            //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- At Page Load:" + "\r\n");
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    private void InitDoc()
    {
        this.Doc = new UploadImageDataSC();
    }

    protected void btnUpld_Click(object sender, EventArgs e)
    {
        m_JpegFlag = m_TiffFlag = false;
        m_EndBatch = "";
        m_StartBatch = 0;
        m_BatchCount = 1;

        m_inwdate = txtinwdate.Text;

        if (Page.IsValid)
        {
           
            TRANS = objDb.getCon().BeginTransaction(); //Added by rutuja 25/07/2019
            try
            {
                if (chkManData.Checked == true)
                {
                    //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- If checked Manadate data checked :" + chkManData + "True" + "\r\n");
                }
                else
                {
                    //if (M_Jpgcount.Count() == 0)
                    //{
                    //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Successful", "alert('Images is not available. Please upload valid zip file.');", true);
                    //    //args.IsValid = false;
                    //    return;
                    //}
                    try
                    {
                        jpgsizevalidate();
                        tifsizevalidate();
                    }
                    catch(Exception ex)
                    {
                        ucErrorCtrll.Display("Error", ex);
                    }
                    pr_MoveImage();
                    TRANS.Commit();  // commit the transaction 
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Successful", "alert('Uploaded Successfully');", true);
                    StrWrt.Close();

                    #region"Added by rutuja 25/07/2019"
                    if (cls_General.GL_NPCIBankCd == "UBIN")
                    {
                        if (RejCount > 0)
                        {
                            lblMsg.Visible = true;
                            txtFilePath.Text = Server.MapPath("~//Data//" + cls_General.GL_CmpnyCd + "//" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy") + "//DispencryReportInUploadImageData_" + cls_General.GL_UsrCd + ".txt");    //DiscrepancyReportInUploadImageData1_
                            linkExcel.Visible = true;
                        }
                    }
                    #endregion

                    lblMandate.Visible = true;
                    lblBatch.Visible = true;
                    lblBatchNos.Visible = true;

                   
                }
                if (File.Exists(Server.MapPath(tmpZip)))
                { 
                    File.Delete(Server.MapPath(tmpZip));
                }

              
            }
            catch (Exception ex)
            {
                TRANS.Rollback();  // for rollbacking the transaction if the transaction fails  **-Added by rutuja 25/07/2019 

                //if (StrWrt.BaseStream != null)
                //{
                //    StrWrt.Close();
                //}
                GC.Collect();
                ucErrorCtrll.Display("Error", ex);
                return;
            }

            #region"added by rutuja 25/07/2019"
            finally
            {
                objDb.gl_dbClose();   //for closing the connection       
            }

            #endregion
        }
    }

    //-----------------Upload image in Database -----------------
    //protected void UploadImage_test()
    //{
    //    // Read the file and convert it to Byte Array
    //    string filePath = "D:\\Images\\";
    //    string filename = "00000075.jpg";
    //    string contenttype = "Images/" + Path.GetExtension(filename.Replace(".", ""));

    //    //Path.GetExtension(filename.Replace(".","");
    //    FileStream fs = new FileStream(filePath + filename,
    //    FileMode.Open, FileAccess.Read);
    //    BinaryReader br = new BinaryReader(fs);
    //    Byte[] bytes = br.ReadBytes((Int32)fs.Length);

    //    UploadImageDataBLL objUploadImageDataBLL = new UploadImageDataBLL();
    //    DataSet DS = new DataSet();
    //   // objUploadImageDataBLL.UploadImage_test(bytes);
    //}
    public void checkZip(string ZipFileName)
    {
        if (!File.Exists(Server.MapPath(tmpZip)))
        {
            return;
        }
        //using (ZipArchive za =zip ZipFile.OpenRead(tmpZip))
        //{
        //    foreach (ZipArchiveEntry zaItem in za.Entries)
        //    {
        //        if (zaItem.FullName.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
        //        {
        //            result = "Success";
        //        }
        //        else
        //        {
        //            result = "No ico files has been found";
        //        }
        //    }
        //}
        //using (ZipFile zip = ZipFile.Read(tmpZip))
        //{
        //    zip.ExtractAll(extractPath, ExtractExistingFileAction.DoNotOverwrite);
        //    GridView1.DataSource = zip.Entries;
        //    GridView1.DataBind();
        //}

        //int foldersCount;
        //using (var zip = ZipFile.OpenRead(ZipFileName))
        //{
        //    foldersCount = zip.Entries.Count(e => e.FullName.Split('/').Length == 3 && e.FullName.EndsWith("/"));
        //}
        //using (ZipArchive archive = ZipFile.OpenRead(ZipFilePath))
        //{
        //        List<ZipArchiveEntry> listOfZipFolders = new List<ZipArchiveEntry>();
        //        foreach (ZipArchiveEntry entry in archive.Entries)
        //        {
        //            if (entry.FullName.EndsWith("/"))
        //                listOfZipFolders.Add(entry);
        //        }
        //        int foldersCount = listOfZipFolders.Count;
        //}

    }


    public void save(string ZipFileName)
    {
        string m_source, m_destincation;
        bool forDirector = false;
        if (!File.Exists(Server.MapPath(tmpZip)))
        {
            return;
        }

        //using (ZipInputStream D = new ZipInputStream(File.OpenRead(Server.MapPath(tmpZip)))
        //{
        //    Zi
        //}

        using (ZipInputStream s = new ZipInputStream(File.OpenRead(Server.MapPath(tmpZip))))
        {
            ZipEntry theEntry;

            while ((theEntry = s.GetNextEntry()) != null)
            {

                //string directoryName = Path.GetDirectoryName(theEntry.Name);   //tmpZip stores the image path  comment on 17/11/2020 for heck the image path.

                string directoryName = Path.GetDirectoryName(tmpZip);
                string fileName = Path.GetFileName(theEntry.Name);
                if (forDirector == false)
                {
                    if (directoryName.Length > 0)
                    {
                        m_source = cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
                        m_destincation = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");

                        if (Directory.Exists(m_source))
                        {
                            DirectoryInfo DIR = new DirectoryInfo(m_source);
                            foreach (FileInfo FI in DIR.GetFiles())
                            {
                                FI.Delete();
                            }
                        }
                        if (Directory.Exists(m_destincation))
                        {
                            DirectoryInfo DIR = new DirectoryInfo(m_destincation);
                            foreach (FileInfo FI in DIR.GetFiles())
                            {
                                FI.Delete();
                            }
                        }

                        if (!Directory.Exists(m_source))
                        {
                            Directory.CreateDirectory(cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy"));
                            
                        }
                        if (!Directory.Exists(m_destincation))
                        {
                            Directory.CreateDirectory(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy"));
                        }

                        forDirector = true;
                    }
                    else
                    {
                        //ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please upload valid .zip file!')", true);
                        ValidZip = false;
                        return;
                    }
                }

                if (fileName != String.Empty)
                {
                    using (FileStream streamWriter = File.Create(cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy") + "//" + fileName))
                    {

                        int size = 2048;
                        byte[] data = new byte[2048];
                        while (true)
                        {
                            size = s.Read(data, 0, data.Length);
                            if (size > 0)
                            {
                                streamWriter.Write(data, 0, size);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }

                }



            }
            
        }

        m_source = cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
        m_destincation = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
        string[] m_AllJpeg;
        m_AllJpeg = Directory.GetFiles(m_source + "\\", "*.jpg", SearchOption.AllDirectories);
        bool directmove = false;
        string tempDestination;
        string tempSource;
        if(m_AllJpeg.Length > 0)
        {
            int quality = 0;
             for (int i = 0; i < m_AllJpeg.Length; i++)
             {
                 directmove = false;
                 tempSource = "";
                 tempDestination = "";
                 string filename1 = m_AllJpeg[i];
                 string fullPatchName =  filename1;
                 tempSource = m_source + "\\" + Path.GetFileName(filename1.Trim());

                 tempDestination = m_destincation + "\\" + Path.GetFileName(filename1.Trim());
                 
                 FileInfo fileInfo = new FileInfo(fullPatchName);
                 quality = 0;
                // int x = 0;
                 if (fileInfo.Length >= 60000 && fileInfo.Length < 100000)
                 {
                     quality = 40;
                 }
                 else if (fileInfo.Length >= 100000 && fileInfo.Length < 200000)
                 {
                     quality = 30;
                 }
                 else if (fileInfo.Length >= 200000 && fileInfo.Length < 300000)
                 {
                     quality = 20;
                 }
                 else if (fileInfo.Length >= 300000)
                 {
                     quality = 10;
                 }
                 else if (fileInfo.Length < 60000)
                 {
                     directmove = true;
                     File.Move(tempSource, tempDestination);
                 }
                 else
                 {
                     quality = 10;
                 }


                 //switch (x)
                 //{
                 //    case 1:
                 //        quality = 20;
                 //        break;
                 //    case 2:
                 //        quality = 30;
                 //        break;
                 //    case 3:
                 //        quality = 40;
                 //        break;
                 //    case 4:
                 //        quality = 10;
                 //        break;
                 //    default:
                 //        quality = 10;
                 //        break;
                 //}

                 if (directmove==false)
                 { 

                    CompressImage(tempSource, tempDestination, quality);
                 }
               
             }
             m_source = cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
             if (Directory.Exists(m_source))
             {
                 DirectoryInfo DIR = new DirectoryInfo(m_source);
                 foreach (FileInfo FI in DIR.GetFiles())
                 {
                     FI.Delete();
                 }
                 Directory.Delete(m_source, true);
             }

        
        }

        //CompressImageForFolder(m_source,m_destincation,)

    }


    public void secondtifsave(string fullPathName)
    {
        bool directmove = false;
        string m_destincation = cls_General.GL_ImagePathTemp + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
        string m_source = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");


        if (Directory.Exists(m_destincation))
        {
            DirectoryInfo DIR = new DirectoryInfo(m_destincation);
            foreach (FileInfo FI in DIR.GetFiles())
            {
                FI.Delete();
            }
        }


        if (!Directory.Exists(m_destincation))
        {
            Directory.CreateDirectory(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy"));
        }


        FileInfo fileInfo = new FileInfo(fullPathName);
        int quality = 0;
        // int x = 0;
        if (fileInfo.Length >= 30000 && fileInfo.Length < 60000)
        {
            quality = 40;
        }
        else if (fileInfo.Length >= 50000 && fileInfo.Length < 100000)
        {
            quality = 30;
        }
        else if (fileInfo.Length >= 100000 && fileInfo.Length < 150000)
        {
            quality = 20;
        }
        else if (fileInfo.Length >= 150000)
        {
            quality = 10;
        }

        else
        {
            quality = 10;
        }


    }
    

    public static void CompressImageForFolder(string SoucePath, string DestPath, int quality)
    {
        string qs = quality.ToString();
        string dt = DateTime.Now.ToString("_HHmmss_ddMMyyyy");
        string add = dt + "_" + qs + "%_Compressed_Images";
        var FileName = Path.GetFileName(SoucePath);
        DestPath = DestPath + "\\" + FileName.Insert(FileName.Length - 4, add);

        using (Bitmap bmp1 = new Bitmap(SoucePath))
        {
            ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);

            System.Drawing.Imaging.Encoder QualityEncoder = System.Drawing.Imaging.Encoder.Quality;

            EncoderParameters myEncoderParameters = new EncoderParameters(1);

            EncoderParameter myEncoderParameter = new EncoderParameter(QualityEncoder, quality);

            myEncoderParameters.Param[0] = myEncoderParameter;
            bmp1.Save(DestPath, jpgEncoder, myEncoderParameters);
        }
    }  

    public static void CompressImage(string sourceImage, string DestPath, int quality)
    {
        string qs = quality.ToString();
        string dt = DateTime.Now.ToString("_HHmmss_ddMMyyyy");
       // string add = dt + "_" + qs + "%_Compressed_Images";
        //DestPath = DestPath + "\\" + ogfilename.Insert(ogfilename.Length - 4, add);
        //dstnsizeuse = DestPath;

        using (Bitmap bmp1 = new Bitmap(sourceImage))
        {
            ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);

            System.Drawing.Imaging.Encoder QualityEncoder = System.Drawing.Imaging.Encoder.Quality;

            EncoderParameters myEncoderParameters = new EncoderParameters(1);

            EncoderParameter myEncoderParameter = new EncoderParameter(QualityEncoder, quality);

            myEncoderParameters.Param[0] = myEncoderParameter;
            bmp1.Save(DestPath, jpgEncoder, myEncoderParameters);
            bmp1.Dispose();


            
            
        }
    }
    private static ImageCodecInfo GetEncoder(ImageFormat format)
    {
        ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
        foreach (ImageCodecInfo codec in codecs)
        {
            if (codec.FormatID == format.Guid)
            {
                return codec;

            }
            
        }
        return null;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //navigate to home page 
        Response.Redirect("~/Home.aspx");
    }

    protected void pr_MoveImage()
    {
        m_ImageFlag = false;
        m_jpgCnt = m_tifCnt = 0;
        M_StartFlag = false;
        m_jpgCnt = m_tifCnt = 0;
        try
        {


            if (pr_ImageCheck() == true)
            {
               
                return;
            }

        lblFirst:
            m_ImgCount = 0;
            M_MaxPouchTo = 0;
            m_ImgName = "";


            M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpg");


                OracleDataReader drPouch;   //added on 25/07/2019

                this.Doc.RecType = "MAX";
                this.Doc.BatchTable = cls_General.GL_Batch;
                UploadImageDataBLL objUploadImageDataBLL = new UploadImageDataBLL();
                DataSet dsPouch = new DataSet();
                dsPouch = objUploadImageDataBLL.GetData(this.Doc);
                if (dsPouch != null && dsPouch.Tables[0].Rows.Count > 0)
                {
                    //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- get image count :" + "number of image " + "\r\n");
                    M_MaxPouchFrom = Convert.ToInt32(dsPouch.Tables[0].Rows[0]["POUCHTO"].ToString());
                    M_MaxPouchTo = Convert.ToInt32(dsPouch.Tables[0].Rows[0]["POUCHTO"].ToString());
                }
                this.Doc.RecType = "Batch";
                this.Doc.BatchTable = cls_General.GL_Batch;
                this.Doc.UtilityCode = cls_General.GL_NACHUtilityCd;
                objUploadImageDataBLL = new UploadImageDataBLL();
                DataSet DS = new DataSet();
                DS = objUploadImageDataBLL.GetData(this.Doc);

                if (DS != null && DS.Tables[0].Rows.Count > 0)
                {
                    //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- get batch count :" + cls_General.GL_Batch + "create new batch " + "\r\n");

                    m_Batch = Convert.ToInt32(DS.Tables[0].Rows[0]["BATCH"].ToString());
                    //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- For batch count :" + m_Batch + "batch" + "\r\n");
                    if (M_StartFlag == false)
                    {
                        m_StartBatch = m_Batch;
                    }

                    if (Directory.Exists(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch))
                    {
                        DirectoryInfo DIR = new DirectoryInfo(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch);
                        foreach (FileInfo FI in DIR.GetFiles())
                        {
                            FI.Delete();
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch);
                    }


                   
                   // while (m_jpgCnt < m_AllJpeg.Length)
                    for (int i = 0; i < m_AllJpeg.Length; i++ )
                    {
                        if (m_ImgCount >= 50)
                        {
                            m_BatchCount++;
                            M_StartFlag = true;
                            break;
                        }


                        string m_pathimg = string.Empty;
                        //m_pathimg = cls_General.GL_ImagePath + cls_General.GL_UsrNm + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_AllJpeg[m_jpgCnt].ToString());
                       // if (imagenottomove.Contains(System.IO.Path.GetFileName(m_AllJpeg[m_jpgCnt].ToString().Replace(".tif", "").Replace(".jpg", ""))))
                        if (imagenottomove.Contains(System.IO.Path.GetFileName(m_AllJpeg[i].ToString().Replace(".tif", "").Replace(".jpg", ""))))
                        {

                        }
                        else
                        {
                           

                           // m_pathimg = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_AllJpeg[m_jpgCnt].ToString());
                            m_pathimg = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_AllJpeg[i].ToString());
                            m_ImgName = M_MaxPouchTo.ToString().PadLeft(8, '0') + ".jpg"; //01012021
                           // m_ImgName= System.IO.Path.GetFileName(m_AllJpeg[i].ToString());
                           // Thread.Sleep(5000);
                            string jpgmove = string.Empty;
                            string m_moveFile = string.Empty;
                            m_moveFile =cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0');

                            movefile.Add(m_pathimg + "," + m_moveFile);
                           
                            File.Move(m_pathimg, cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));
                          
                            // File.Copy(m_pathimg, cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));
                            //File.Move(m_pathimg, cls_General.GL_ImagePath + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));



                            m_ImgName = M_MaxPouchTo.ToString().PadLeft(8, '0') + ".tif"; //01012021
                           // m_ImgName = System.IO.Path.GetFileName(m_tiff[i].ToString());


                            m_pathimg = "";
                            m_moveFile = "";
                            //m_pathimg = cls_General.GL_ImagePath + cls_General.GL_UsrNm + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_tiff[m_jpgCnt].ToString());

                           // m_pathimg = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_tiff[m_jpgCnt].ToString());
                            m_pathimg = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\" + System.IO.Path.GetFileName(m_tiff[i].ToString());
                           
                            m_moveFile = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0');
                           // Thread.Sleep(5000);
                            //File.Move(m_pathimg, cls_General.GL_ImagePath + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));
                            movefile.Add(m_pathimg + "," + m_moveFile);
                          //   File.Move(m_pathimg, cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));
                          //  File.Copy(m_pathimg, cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));

                            //File.Copy(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'), (System.Configuration.ConfigurationManager.AppSettings["SMSSavePath"].ToString() + cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0')));

                            //File.Copy(cls_General.GL_ImagePath + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'), @"Y:\Images\" + cls_General.GL_NACHUtilityID + "\\" + m_Batch + "\\" + m_ImgName.PadLeft(8, '0'));
                            m_ImgCount++;
                            M_MaxPouchTo++;
                           

                        }
                        m_jpgCnt++;
                    }

                        
                    }
               

                this.Doc.BatchTable = cls_General.GL_Batch;
                this.Doc.BatchNo = m_Batch.ToString();
                this.Doc.MaxPouchFrom = M_MaxPouchFrom.ToString();
                this.Doc.MaxPouchT = Convert.ToInt32(M_MaxPouchTo);
                this.Doc.NO_OF_Mandate = Convert.ToInt32(M_MaxPouchTo - M_MaxPouchFrom);
                this.Doc.Batch_Date = cls_General.GL_SystmDt;
                this.Doc.UsrCd = cls_General.GL_UsrCd.ToString();
                this.Doc.UtilityCode = cls_General.GL_NACHUtilityCd;
                this.Doc.UtilityID = cls_General.GL_NACHUtilityID;
                this.Doc.NPCIBankCd = cls_General.GL_NPCIBankCd; // new change
                this.Doc.SoleID = txtSolId.Text.Trim(); // new change                
                this.Doc.INWDate = txtinwdate.Text.Trim();

                objUploadImageDataBLL = new UploadImageDataBLL();
                DataSet Ds = new DataSet();
                Ds = objUploadImageDataBLL.Upload(this.Doc);
                if (m_jpgCnt < m_AllJpeg.Length)
                {
                  //  goto lblFirst;  //31122020
                }


                m_EndBatch = m_Batch.ToString();
                lblBatch.Text = "No of Batches: " + m_BatchCount;

                if (Convert.ToInt32(m_StartBatch) != Convert.ToInt32(m_EndBatch))
                {
                    lblBatchNos.Text = "Batch Nos : " + m_StartBatch + "-" + m_EndBatch;
                }
                else
                {
                    lblBatchNos.Text = "Batch No : " + m_StartBatch;
                }

              

                if (cls_General.GL_NPCIBankCd == "UBIN")
                {
                    lblNoOfImages.Text = "Images Uploaded:-" + Convert.ToInt32(M_MaxPouchTo - M_MaxPouchFrom).ToString();
                }
              
                //foreach (string file in Directory.GetFiles(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy")))
                //{
                //    File.Delete(file);
                //}

                //Directory.Delete(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy"));
                cls_General.SetUploadFlagInSession(mUserObj);

              

                Session["Fileformove"] = movefile;

                string filePath = string.Empty;

                if (RejCount > 0)
                {                   
                    filePath = Server.MapPath("~//Data//" + cls_General.GL_CmpnyCd + "//" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy") + "//DispencryReportInUploadImageData_" + cls_General.GL_UsrCd + ".txt");    //DiscrepancyReportInUploadImageData1_                    
                }
                if (File.Exists(Server.MapPath(tmpZip)))
                {
                    File.Delete(Server.MapPath(tmpZip));
                }

                Response.Redirect("TempMoveFile.aspx?Batch=" + this.Doc.BatchNo + "&MandateUploade=" + this.Doc.NO_OF_Mandate + "&TotalImage=" + m_jpgCnt + "&FilePath=" + filePath);
               
            }
          
      
        catch (Exception ex)
        {
            ucErrorCtrll.Display("Error", ex);
            return;
        }
    
    }

    private Boolean pr_ImageCheck()
    {
        #region"Comment bcz wrong logic for impty zip.folder on 20082020"
        Boolean m_ImageCheckFlag;

        m_FlNm = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + " DispencryReportInUploadImageData_" + cls_General.GL_UserCode + ".txt";  //"DispencryReportInUploadImageData_" Comment by rutuja

        m_ImageCheckFlag = false;

        //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- To Check Images :" + m_ImageFlag + "check" + "\r\n");

        if (!Directory.Exists(cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy")))
        {
            Directory.CreateDirectory(cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy"));
        }
        if (!File.Exists(m_FlNm))
        {
            StrWrt = new StreamWriter(m_FlNm);
        }
        else
        {
            File.Delete(m_FlNm);
            StrWrt = new StreamWriter(m_FlNm);
        }
        m_JpegFlag = m_TiffFlag = false;

        m_path = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");

        //File.AppendAllText("E:\\Adroit Applications\\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- Create folder where images need to be store :" + m_path + "date folder" + "\r\n");



        M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpg");


        //if (File.Exists(HttpContext.Current.Request.PhysicalApplicationPath + Directory.GetFiles(M_Jpgcount + "\\", "*.jpg")))
        //{
        //    return true;
        //}

        //else
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Successful", "alert('Images is not available. Please upload valid zip file.');", true); //17-07-2020 by rutuja
        //    return false;
        //}

        if (M_Jpgcount.Count() == 0)
        {

            M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpeg");
            m_JpegFlag = true; //comment by rutuja on 17-07-2020 for reason of creating batch without image.
            // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Successful", "alert('Images is not available. Please upload valid zip file.');", true); //17-07-2020 by rutuja

        }

        string[] M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");
        //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- get tiff image count:" + M_Tifcount + " get count of tiff image from the folder " + "\r\n");
        if (M_Tifcount.Count() == 0)
        {
            M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tiff");
            m_TiffFlag = true;

            //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- get tiff image count:" + M_Tifcount + " get count of tiff image from the folder and tiff flag = true " + "\r\n");

        }

        m_tiff = new string[M_Tifcount.Length];
        lblMandate.Text = "No of Images:" + M_Jpgcount.Count().ToString();

        if (m_JpegFlag == true)
        {
            m_AllJpeg = Directory.GetFiles(m_path, "*.jpeg", SearchOption.TopDirectoryOnly);
        }
        else
        {
            m_AllJpeg = Directory.GetFiles(m_path, "*.jpg", SearchOption.TopDirectoryOnly);
        }
        for (int m_xml = 0; m_xml < m_AllJpeg.Length; m_xml++)
        {

            string strEXt = string.Empty; //Added by rutuja 26/07/2019 for checking extension of img file
            m_MatchImage = null;

            strEXt = m_AllJpeg[m_xml].ToString().Substring(m_AllJpeg[m_xml].ToString().LastIndexOf(".") + 1, m_AllJpeg[m_xml].ToString().Length - m_AllJpeg[m_xml].ToString().LastIndexOf(".") - 1);

            if (strEXt.ToString() == "jpg")     //If() condition added by rutuja rest of the part already present
            {
                //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- if extension .jpg :" + strEXt + "converting jpg into tiff " + "\r\n");

                if (m_JpegFlag == true && m_TiffFlag == true)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpeg", ".tiff");
                }
                else if (m_JpegFlag == true && m_TiffFlag == false)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpeg", ".tif");
                }
                else if (m_JpegFlag == false && m_TiffFlag == true)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tiff");
                }
                else
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tif");
                }
            }
            #region"added by rutuja"
            else
            {
                //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- if extension .jpg :" + strEXt + "converting jpginto tiff " + "\r\n");

                if (m_JpegFlag == true && m_TiffFlag == true)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".JPEG", ".tif");
                }
                else if (m_JpegFlag == true && m_TiffFlag == false)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".JPEG", ".tif");
                }
                else if (m_JpegFlag == false && m_TiffFlag == true)
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".JPG", ".tif");
                }
                else
                {
                    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".JPG", ".tif");
                }
            }

            #endregion




            m_jpgName = m_jpgName.ToString().Substring(m_jpgName.ToString().LastIndexOf("\\") + 1, m_jpgName.Length - m_jpgName.ToString().LastIndexOf("\\") - 1);
            m_MatchImage = Directory.GetFiles(m_path, m_jpgName, SearchOption.TopDirectoryOnly);
            //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- match images and pathe of images :" + m_jpgName + "NAme of image" + "\r\n");

            if (m_MatchImage.Length == 1)
            {
                m_tiff[m_xml] = m_MatchImage[0];
                //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- if tiff flag get true valu:" + m_tiff[m_xml] + "  " + "\r\n");
            }
            else
            {
                StrWrt.WriteLine(string.Format("{0,-20} {1,-20} ", m_AllJpeg[m_xml], "Image Not Found"));
                m_ImageFlag = true;
            }
        }
        StrWrt.Close();
        if (m_ImageFlag == true)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert(Jpeg  and tiff image not found.upload fail.Please check the Log File);", true);
            txtFilePath.Text = Server.MapPath("~//Data//" + cls_General.GL_CmpnyCd + "//" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy") + "//DispencryReportInUploadImageData_" + cls_General.GL_UserCode + ".txt");
            m_ImageCheckFlag = true;
            //linkExcel.Visible = true;  comment by rutuja on 31/07/2019
            linkExcel.Visible = false;  //added by rutuja on 31/07/2019
            lblMsg.Visible = true;
            lblMsg.Text = "tiff image not found";
            return m_ImageCheckFlag;
        }
        else
        {
            linkExcel.Visible = lblMsg.Visible = false;
        }

        return m_ImageCheckFlag;
#endregion
        #region"Bandhan Logic for image upload"

        //   Boolean m_ImageCheckFlag;
          
        
        //m_FlNm = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + " DispencryReportInUploadImageData_" + cls_General.GL_UserCode + ".txt";  //"DispencryReportInUploadImageData_" Comment by rutuja
        //m_ImageCheckFlag = false;
        //if (!Directory.Exists(cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy")))
        //{
        //    Directory.CreateDirectory(cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy"));
        //}
        //if (!File.Exists(m_FlNm))
        //{
        //    StrWrt = new StreamWriter(m_FlNm);
        //}
        //else
        //{
        //    File.Delete(m_FlNm);
        //    StrWrt = new StreamWriter(m_FlNm);
        //}
        //m_JpegFlag = m_TiffFlag = false;


        //m_path = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");

   


        //M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpg");


  


  
 
        //if (M_Jpgcount.Count() == 0)
        //{

        //    M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpeg");
        //    m_JpegFlag = true; 
			
        //}
		
        //else
        //    {
        //        m_JpgFlag = true;
        //    }
		

        //string[] M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");
      
        //if (M_Tifcount.Count() == 0)
        //{

        //    M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tiff");
        //     if (M_Tifcount.Count() == 0)
        //            m_TiffFlag = false;
        //        else
        //            m_TiffFlag = true;
        //}
        //else
        //{
        //    m_TiffFlag = true;
        //}
			

        //    if (m_TiffFlag == false)
        //    {
        //        M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");


        //        if (M_Tifcount.Count() == 0)
        //        {
        //            M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");
        //            if (M_Tifcount.Count() == 0)
        //                m_TifFlag = true;
        //            else
        //                m_TifFlag = false;
        //        }
        //        else
        //        {
        //            m_TifFlag = true;
        //        }
        //    }			
        //m_tiff = new string[M_Tifcount.Length];
        //lblMandate.Text = "No of Images:" + M_Jpgcount.Count().ToString();

        //if (m_JpegFlag == true)
        //{
        //    m_AllJpeg = Directory.GetFiles(m_path, "*.jpeg", SearchOption.TopDirectoryOnly);
        //}
        //else
        //{
        //    m_AllJpeg = Directory.GetFiles(m_path, "*.jpg", SearchOption.TopDirectoryOnly);
        //}
        //for (int m_xml = 0; m_xml < m_AllJpeg.Length; m_xml++)
        //{
        //    m_MatchImage = null;
        //    m_MatchImage = null;
        //        if (m_JpegFlag == true && m_TiffFlag == true)
        //        {
        //            m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpeg", ".tiff");
        //        }
        //        else if (m_JpegFlag == true && m_TiffFlag == false)
        //        {
        //            m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpeg", ".tif");
        //        }
        //        else if (m_JpegFlag == false && m_TiffFlag == true)
        //        {
        //            m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tiff");
        //        }

        //        //else if (m_JpegFlag == false && m_TiffFlag == false)
        //        //{
        //        //    m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tiff");
        //        //}
        //        else if (m_JpgFlag == true && m_TifFlag == true)
        //        {
        //            m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tif");
        //        }

        //        else
        //        {
        //            m_jpgName = m_AllJpeg[m_xml].ToString().Replace(".jpg", ".tiff");
        //        }


        //        m_jpgName = m_jpgName.ToString().Substring(m_jpgName.ToString().LastIndexOf("\\") + 1, m_jpgName.Length - m_jpgName.ToString().LastIndexOf("\\") - 1);
        //        m_MatchImage = Directory.GetFiles(m_path, m_jpgName, SearchOption.TopDirectoryOnly);
        //        if (m_MatchImage.Length == 1)
        //        {

        //            m_tiff[m_xml] = m_MatchImage[0];
        //        }
        //        else
        //        {

        //            StrWrt.WriteLine(string.Format("{0,-20} {1,-20} ", m_AllJpeg[m_xml], "Image Not Found"));
        //            m_ImageFlag = true;
        //        }
        //    }


        //    StrWrt.Close();
        //    if (m_ImageFlag == true)
        //    {


        //        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert(Jpeg  and tiff image not found.upload fail.Please check the Log File);", true);
        //        // txtFilePath.Text = Server.MapPath("~//Data//" + cls_General.GL_CmpnyCd + "//" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy") + "//DispencryReportInUploadImageData_" + cls_General.GL_UserCode + ".txt");
        //        txtFilePath.Text = "DispencryReportInUploadImageData_" + cls_General.GL_UserCode + ".txt";
        //        m_ImageCheckFlag = true;
        //        linkExcel.Visible = true;
        //        lblMsg.Visible = true;
        //        return m_ImageCheckFlag;
        //    }
        //    else
        //    {


        //        linkExcel.Visible = lblMsg.Visible = false;
        //    }


        //    return m_ImageCheckFlag;
        #endregion
    }
    
    protected void cvOk_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            if (!IsPageRefresh) // check that page is not refreshed by browser
            {
                string strError = "";
                lblBatch.Text = lblBatchNos.Text = lblMandate.Text = "";
                linkExcel.Visible = lblMsg.Visible = false;

                if (flUpld.PostedFile.FileName == "")
                {
                    cvOk.ErrorMessage = "Please Select Image Path to Upload";
                    args.IsValid = false;
                    return;
                }

                string strSelFile = System.IO.Path.GetFullPath(flUpld.PostedFile.FileName);
                FileInfo finfo = new FileInfo(strSelFile);
                if (finfo.Extension != ".zip" && finfo.Extension != ".ZIP")
                {
                    cvOk.ErrorMessage = "Please Select .zip files Only";
                    args.IsValid = false;
                    return;
                }
                if (flUpld.PostedFile.FileName.Contains('-'))
                {
                    cvOk.ErrorMessage = "Please Select relevent .zip files Only";
                    args.IsValid = false;
                    return;
                }
                //---------------for jpg/jpeg images-------------

                if (Directory.Exists(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy")))
                {
                    M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.*");

                    if (M_Jpgcount.Count() > 0)
                    {
                        foreach (string file in Directory.GetFiles(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy")))
                        {
                            File.Delete(file);
                        }
                    }
                    Directory.Delete(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy"));
                }

                string filename = Path.GetFileName(flUpld.PostedFile.FileName);
                string mExtension = Path.GetExtension(filename);

                filename = filename.Replace(mExtension, "") + "_" + DateTime.Now.ToString("ddMMMyyyy_HHmmss") + mExtension;
                string path = Server.MapPath("~/Data/" + filename);
                flUpld.PostedFile.SaveAs(path);

                // string[] sDirectoryInfo = Directory.GetFiles(path, "*.*");

                tmpZip = "~/Data/" + filename;
                temp = cls_General.GL_ImagePathOuter;
                save(path);
                if (ValidZip == false)
                {
                    cvOk.ErrorMessage = "Please Select relevent .zip files Only";
                    args.IsValid = false;
                    return;
                }

                m_path = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");


                M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpg"); //Uncomment by rutujaon 26/07/2019  -----to get image count 

              

                   
                

                //============================================================================================================================================================================
                #region flattbed scanner "Uncomment by Rutuja on 25/07/2019"
                if (cls_General.GL_NPCIBankCd == "SYNB" || cls_General.GL_NPCIBankCd == "CNSX" || cls_General.GL_NPCIBankCd == "ORBC" || cls_General.GL_NPCIBankCd == "PGBX" || cls_General.GL_NPCIBankCd == "KLGB" || cls_General.GL_NPCIBankCd == "JSAB" || cls_General.GL_NPCIBankCd == "KODX" || cls_General.GL_NPCIBankCd == "RATN" || cls_General.GL_NPCIBankCd == "USFB" || cls_General.GL_NPCIBankCd == "UBIN")
                {


                    if (chkfb.Checked == true)
                    {
                        //File.AppendAllText("E:\\Adroit Applications\test.txt", "DateTime:" + DateTime.Now.ToString() + "--- if flatbed scanner check :" + chkfb + "true flatbed scanner " + "\r\n");
                        string[] m_AllXml;
                        //m_AllXml = Directory.GetFiles(m_DirName, "*.jpg", SearchOption.AllDirectories);
                        m_AllXml = Directory.GetFiles(m_path + "\\", "*.jpg", SearchOption.AllDirectories);
                        //m_JpgImage = new string[m_AllXml.Length];
                        //m_tiffImage = new string[m_AllXml.Length];
                        Process cmd = new Process();
                        for (int i = 0; i < m_AllXml.Length; i++)
                        {
                            string[] filename1 = m_AllXml[i].Split('.');
                            //string[] filename1 = new string[] {Path.GetDirectoryName((m_AllXml[i]) + "\\" + Path.GetFileNameWithoutExtension(m_AllXml[i]))}; //Shailesh

                            //Process cmd = new Process();
                            //if (temp1 == m_AllXml[i])
                            //{

                            //}
                            //---------------------30122020
                            cmd.StartInfo.FileName = "cmd.exe";
                            cmd.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            cmd.StartInfo.Arguments = "/C  i_view32.exe " + m_AllXml[i] + "/convert=" + filename1[0] + ".tif";
                            cmd.Start();
  
                            //-------------------------30122020

                            cmd.StartInfo.FileName = "cmd.exe";
                            cmd.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            //cmd.StartInfo.Arguments = "/C  i_view32.exe " + m_AllXml[i] + " /resize=(725,350)/dpi=(100,100)/resample/aspectratio/jpg=50/gray /convert=" + m_AllXml[i] + "/jpg=/silent";
                            cmd.StartInfo.Arguments = "/C  i_view32.exe " + m_AllXml[i] + " /resize=(725,350)/dpi=(100,100)/resample/aspectratio/jpgq=50/gray /convert=" + m_AllXml[i] + "/jpg=/silent";

                            cmd.Start();

                            cmd.StartInfo.FileName = "cmd.exe";
                            cmd.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            //cmd.StartInfo.Arguments = "/C  i_view32.exe " + filename1[0] + ".tif" + " /resize=(750,350)/dpi=(100,100)/resample/aspectratio/tif=50 /convert=" + filename1[0] + ".tif" + "/tif=/silent";
                            cmd.StartInfo.Arguments = "/C  i_view32.exe " + filename1[0] + ".tif" + " /resize=(750,350)/dpi=(200,200)/resample/aspectratio/tifc=3 /convert=" + filename1[0] + ".tif" + "/tif=/silent";  //30122020
                           // cmd.StartInfo.Arguments = "/C  i_view32.exe " + m_AllXml[i] + " /resize=(750,350)/dpi=(200,200)/resample/aspectratio/tifc=4 /convert=" + filename1[0] + ".tif" + "/tif=/silent";
                            cmd.Start();


                           
                        }
                         
                        cmd.WaitForExit();
                        Thread.Sleep(1000);     
                    }
                }
                #endregion flattbed scanner
                //============================================================================================================================================================================

     

      
        if (M_Jpgcount.Count() == 0)
        {
            M_Jpgcount = Directory.GetFiles(m_path + "\\", "*.jpeg");
            m_JpegFlag = true;
        }
        
            if (M_Jpgcount.Count() == 0)
                {
                    cvOk.ErrorMessage = "Jpeg/Jpg Images not Found";
                    flUpld.Focus();
                    args.IsValid = false;
                    return;
                }
                string[] M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");

                if (M_Jpgcount.Count() != M_Tifcount.Count())
                {
                    Thread.Sleep(1000);
                    M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tif");
                }

                if (M_Tifcount.Count() == 0)
                {
                    M_Tifcount = Directory.GetFiles(m_path + "\\", "*.tiff");
                    m_TiffFlag = true;
                }

                
                    if (M_Jpgcount.Count() != M_Tifcount.Count())
                    {
                        cvOk.ErrorMessage = "jpg and tif Images count is not Tally";
                        flUpld.Focus();
                        args.IsValid = false;
                        return;
                    }
                 

               
                cvOk.ErrorMessage = "";
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;    // if page is refreshed then set false
                Clear();
            }

        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }


  

    protected void linkExcel_Click(object sender, EventArgs e)
    {
        try
        {
            System.IO.FileStream fs = null;
            fs = System.IO.File.Open(txtFilePath.Text, System.IO.FileMode.Open);    //E:\Rutuja\UBI\MMS1\MMS\Data\15\29072019
            byte[] btFile = new byte[fs.Length];
            fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            Response.AddHeader("Content-disposition", "attachment; filename=DispencryReportInUploadImageData.txt");
            Response.ContentType = "application/octet-stream";
            Response.BinaryWrite(btFile);
            Response.End();
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    protected void ddlSelBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            Clear();
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    private void Clear()
    {
        lblMandate.Visible = false;
        lblMandate.Text = "";
        lblBatch.Visible = false;
        lblBatch.Text = "";
        lblBatchNos.Visible = false;
        lblBatchNos.Text = "";
        lblMsg.Visible = false;
        linkExcel.Visible = false;
    }

    protected void jpgsizevalidate()
    {

        m_FlNm = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + "DispencryReportInUploadImageData_" + cls_General.GL_UsrCd + ".txt";    //DiscrepancyReportInUploadImageData1_ DispencryReportInUploadImageData_
        if (File.Exists(m_FlNm))
        {
            File.Delete(m_FlNm);
        }
        using (SW = new StreamWriter(m_FlNm))
        {
            SW.WriteLine(string.Format("{0,17}          {1,18}      {2,20}        {3,6}  ", "Rejected FileName", "VerticalResolution", "HorizontalResolution", "Reason"));
            string m_destincationfile = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
            bool jpgRej = false;
            string[] m_AllJpeg;
            m_AllJpeg = Directory.GetFiles(m_destincationfile + "\\", "*.jpg", SearchOption.AllDirectories);

            string filenameforadd = string.Empty;
            if (m_AllJpeg.Length > 0)
            {
                for (int i = 0; i < m_AllJpeg.Length; i++)
                {
                    
                    jpgRej = false;
                    // string filename1 = m_AllJpeg[i];
                    //string fullPatchName = filename1;
                    //tempSource = m_destincationfile + "\\" + Path.GetFileName(filename1.Trim());

                    FileInfo fileInfo = new FileInfo(m_AllJpeg[i]);
                    if (fileInfo.Length > 60000)
                    {
                        jpgRej = true;
                        SW.WriteLine(string.Format("{0,8}    {1,12}   {2,15}    {3,20}", Path.GetFileName(m_AllJpeg[i]), vres, hres, "Size is greator than 60 Kb"));

                        filenameforadd = Path.GetFileName(m_AllJpeg[i]).Replace(".jpg", "");

                        imagenottomove.Add(filenameforadd);

                        //File.Delete(m_AllJpeg[i].Replace("jpg", "tif"));
                        RejCount++;
                        continue;

                    }
                    System.Drawing.Image image = System.Drawing.Image.FromFile(m_AllJpeg[i]);
                    hres = image.HorizontalResolution;
                    vres = image.VerticalResolution;
                    int height = image.Height;
                    int width = image.Width;
                    if (jpgRej == false)
                    {
                        if (hres > 100 || vres > 100)
                        {
                            SW.WriteLine(string.Format("{0,8} {1,12} {2,15}  {3,20}", Path.GetFileName(m_AllJpeg[i]), vres, hres, "Resolution of this Image should be less than 100 DPI"));

                            filenameforadd = Path.GetFileName(m_AllJpeg[i]).Replace(".jpg", "");

                            imagenottomove.Add(filenameforadd);
                            //  temp1 = ImagePath + "," + temp1; 
                          
                            //File.Delete(m_AllJpeg[i]);

                            //File.Delete(m_AllJpeg[i].Replace("jpg", "tif"));
                            RejCount++;
                        }
                    }

                }

            }

        }
    }


    protected void tifsizevalidate()
    {

        m_FlNm = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + "DispencryReportInUploadImageData_" + cls_General.GL_UsrCd + ".txt";    //DiscrepancyReportInUploadImageData1_ DispencryReportInUploadImageData_
        if (File.Exists(m_FlNm))
        {
            File.Delete(m_FlNm);
        }
        using (SW = new StreamWriter(m_FlNm))
        {
            SW.WriteLine(string.Format("{0,17}          {1,18}      {2,20}        {3,6}  ", "Rejected FileName", "VerticalResolution", "HorizontalResolution", "Reason"));
            string m_destincationfile = cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_UsrNm + "\\" + DateTime.Now.ToString("ddMMyyyy");
            
          
            string[] m_Alltif;
            m_Alltif = Directory.GetFiles(m_destincationfile + "\\", "*.tif", SearchOption.AllDirectories);
            bool tiffRej = false;
            //string tempDestination;
            //string tempSource;           
            if (m_Alltif.Length > 0)
            {

                for (int i = 0; i < m_Alltif.Length; i++)
                {
                   
                    tiffRej = false;
                    // string filename1 = m_AllJpeg[i];
                    //string fullPatchName = filename1;
                    //tempSource = m_destincationfile + "\\" + Path.GetFileName(filename1.Trim());

                    string filenameforadd = string.Empty;
                    FileInfo fileInfo = new FileInfo(m_Alltif[i]);
                    if (fileInfo.Length > 30000)
                    {
                        tiffRej = true;
                        SW.WriteLine(string.Format("{0,8} {1,12} {2,15}  {3,50}", Path.GetFileName(m_Alltif[i]), vres, hres, "Tif size is greator than 30 KB"));
                        filenameforadd = Path.GetFileName(m_Alltif[i]).Replace(".tif", "");

                        imagenottomove.Add(filenameforadd);
                        //imagenottomove.Add(m_Alltif[i]);

                        //File.Delete(m_Alltif[i]);
                        //Thread.Sleep(10000);
                        //if (File.Exists(m_Alltif[i].Replace("tif", "jpg")))
                        //{
                        //    File.Delete(m_Alltif[i].Replace("tif", "jpg"));
                        //}
                        RejCount++;
                        continue;

                    }
                    System.Drawing.Image image = System.Drawing.Image.FromFile(m_Alltif[i]);
                    hres = image.HorizontalResolution;
                    vres = image.VerticalResolution;

                    int height = image.Height;
                    int width = image.Width;


                    if (tiffRej == false)
                    {
                        if (hres > 200 || vres > 200)
                        {
                            SW.WriteLine(string.Format("{0,8} {1,12} {2,15} {3,100}", Path.GetFileName(m_Alltif[i]), vres, hres, "Resolution of this Tif Image should be less than 200 DPI"));
                            Thread.Sleep(1000);
                            File.Delete(m_Alltif[i]);
                            Thread.Sleep(1000);
                            File.Delete(m_Alltif[i].Replace(".tif", ".jpg"));
                            // temp1 = ImagePath + "," + temp1;
                            RejCount++;
                        }
                    }

                }





            }

        }

    }

    protected void lnkBtnDetails_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("TempMoveFile.aspx?Batch=" + lblBatchNos.Text + "MandateUploade=" + lblMandate.Text + "TotalImage=" + m_jpgCnt);
            //Response.Redirect("DownloadFilesTemp.aspx?FileName=" + strFileName + "&Module=" + ddlModule.SelectedItem.Text + "&SettlementDate=" + settlementDate);
        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

}

