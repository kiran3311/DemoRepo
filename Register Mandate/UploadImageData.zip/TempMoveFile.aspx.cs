﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Register_Mandate_TempMoveFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string strFilePath = string.Empty;
            string strBatch = Request.QueryString["Batch"];
            string fileUploaded = Request.QueryString["MandateUploade"];
            string TotalImage = Request.QueryString["TotalImage"];
            string Filepatth = Request.QueryString["FilePath"];

            //Batch=" + lblBatchNos.Text + "MandateUploade=" + this.Doc.NO_OF_Mandate + "TotalImage=" + m_jpgCnt

            // Response.Redirect("TempMoveFile.aspx?Batch=" + this.Doc.BatchNo + "&MandateUploade=" + this.Doc.NO_OF_Mandate + "&TotalImage=" + m_jpgCnt + "&FilePath=" + filePath);

            List<string> FileToMove = new List<string>();
            FileToMove = (List<string>)Session["Fileformove"];
            string directoryToDelete = string.Empty;


            bool Filetodel = false;
            if (!string.IsNullOrEmpty(strBatch))
            {
                if (FileToMove.Count() > 0)
                {
                    foreach (string str in FileToMove)
                    {
                        string[] filesplit = str.Split(',');
                        File.Move(filesplit[0], filesplit[1]);

                        if (Filetodel == false)
                        {
                            int valueofFile = Path.GetFullPath(filesplit[0]).LastIndexOf('\\');

                            directoryToDelete = Path.GetFullPath(filesplit[0]).Substring(0, valueofFile);

                            Filetodel = true;
                        }


                    }

                    if (Directory.Exists(directoryToDelete))
                    {
                        DirectoryInfo DIR = new DirectoryInfo(directoryToDelete);
                        foreach (FileInfo FI in DIR.GetFiles())
                        {
                            FI.Delete();
                        }

                        Directory.Delete(directoryToDelete);

                    }


                }



            }

            if (!string.IsNullOrEmpty(Filepatth))
            {
                lblMsg.Visible = true;
                // txtFilePath.Text = Server.MapPath("~//Data//" + cls_General.GL_CmpnyCd + "//" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy") + "//DispencryReportInUploadImageData_" + cls_General.GL_UsrCd + ".txt");    //DiscrepancyReportInUploadImageData1_
                txtFilePath.Text = Filepatth;
                linkExcel.Visible = true;
            }

            lblBatch.Text = "Batche No :- " +strBatch;
            lblMandate.Text =  "Images Uploaded :- " +fileUploaded;
            lblBatchNos.Text = "Total image :- "+ TotalImage;
            lblOfRejected.Text = "Rejected Count :- " + (Convert.ToInt64(TotalImage) - Convert.ToInt64(fileUploaded)).ToString();
            lblMandate.Visible = true;
            lblBatch.Visible = true;
            lblBatchNos.Visible = true;

            


        }

    }

    protected void linkExcel_Click(object sender, EventArgs e)
    {
        try
        {
            System.IO.FileStream fs = null;
            fs = System.IO.File.Open(txtFilePath.Text, System.IO.FileMode.Open);    //E:\Rutuja\UBI\MMS1\MMS\Data\15\29072019
            byte[] btFile = new byte[fs.Length];
            fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            Response.AddHeader("Content-disposition", "attachment; filename=DispencryReportInUploadImageData.txt");
            Response.ContentType = "application/octet-stream";
            Response.BinaryWrite(btFile);
            Response.End();
        }
        catch (Exception err)
        {
            
        }
    }
}