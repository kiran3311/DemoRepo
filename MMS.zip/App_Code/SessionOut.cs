﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SessionOut
/// </summary>

public class SessionOut
{
    public int UserCode { get; set; }
    public string NACHUtilityMaster { get; set; }
    public string Batch { get; set; }
    public string MandateData { get; set; }
    public string NACHDestInw { get; set; }
    public string NACHDest { get; set; }
    public bool CompanySelected { get; set; }

	public SessionOut()
	{
        CompanySelected = false; 
	}
}