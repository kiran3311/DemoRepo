﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for APIObjects
/// </summary>
public class APITxnReqObj
{
    public APITxnReqObj()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    //----------Account Enquiry ------------------
    
    
    //---------- For Finnacle ----------------------

    public string RequestUUID { get; set; }
    public string ServiceReqId { get; set; } 
    public string ServiceReqVersion { get; set; }
    public string ChannelId { get; set; }
    public string BankId { get; set; }
    public string MessageDateTime { get; set; }
    public string ValueDt { get; set; }
    public string SettltmentAccNo { get; set; }

    public string TrnType { get; set; }
    public string TrnSubType { get; set; }

    public string AccID { get; set; }
    public string CreditDebitFlg { get; set; }    
    public string TrnParticulars { get; set; }    // TRAN ID
        
    //--------------------------------------------

    //---------- For Ganseva ----------------------
    public Char[] MTI_Details { get; set; }
    public string PrimaryAccountNumber { get; set; }
    public string ProcessingCode { get; set; }

    public string AmountTxn { get; set; }
    public string Systems_TraceAuditNumber { get; set; }
    public string TimeLocalTransaction { get; set; }
    public string DateCapture { get; set; }
    public string Network_International_Identifier { get; set; }    // TRAN ID
    public string Acquiring_Institution_IdentificationCode { get; set; }
    public string PrimaryAccountNumber_Extended { get; set; }
    public string Retrieval_ReferenceNumber { get; set; }
    public string CardAcceptor_TerminalIdentification { get; set; }
    public string CardAcceptor_IdentificationCode { get; set; }
    public string CardAcceptor_NameLocation { get; set; }    
    public string AccountIdentification { get; set; }
    public string ReservedPrivate_123 { get; set; }  // 
    public string ReservedPrivate_124 { get; set; }

    //--------------------------------------------
    public string API_URL { get; set; }
    public string XML { get; set; }
    public string Param { get; set; }
    public string CurrencyCode { get; set; }
    public string CBSType { get; set; } 
}