﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
////using //Oracle.DataAccess.Client;
//using Oracle.DataAccess.Types;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;


namespace NACH_Application
{
    public class cls_DBConnection
    {       
        ADODB.Connection cnNach = new ADODB.Connection();
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["NACH_UAT"].ConnectionString);
         OracleConnection con = new OracleConnection(ConfigurationManager.ConnectionStrings["NACHUAT_BKP"].ConnectionString);
        OracleCommand cmd = new OracleCommand();
        
        public cls_DBConnection()
        {
            cmd.Connection = con;
            if (con.State == ConnectionState.Closed) 
                con.Open();
        }
        public OracleConnection getCon()
        {
            cmd.Connection = con;
            if (con.State == ConnectionState.Closed)
                con.Open();
            return con;
        }
        public void gl_dbClose()
        {
            con.Close();
        }
        public int gl_ExeNonQuery(string m_str)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = m_str;
            int i = cmd.ExecuteNonQuery();
            return i;
        }

        public object gl_exeScalar(string m_str)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = m_str;
            object ob = cmd.ExecuteScalar();
            return ob;
        }

        public OracleDataReader gl_ExeReader(string m_str)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            OracleCommand cmd1 = new OracleCommand();
            cmd1.Connection = con;
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = m_str;
            OracleDataReader dr = cmd1.ExecuteReader();
            return dr;

        }

        public DataSet gl_ExeDataSet(string m_str)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = m_str;
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public DataTable gl_ExeDataTable(string m_str)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = m_str;
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void gl_FillCombo(string m_str, DropDownList cbx, string m_TextField, string m_ValueField)
        {
            DataSet ds1 = new DataSet();
            cbx.DataTextField = m_TextField;
            cbx.DataValueField = m_ValueField;          
            ds1 = gl_ExeDataSet(m_str);
            cbx.DataSource = ds1.Tables[0];
            cbx.DataBind();
        }
        
        public void gl_FillListBox(string m_str, ListBox lst, string m_TextField, string m_ValueField)
        {
            DataSet dslst = new DataSet();
            lst.DataTextField = m_TextField;
            lst.DataValueField = m_ValueField;
            dslst = gl_ExeDataSet(m_str);
            lst.DataSource = dslst.Tables[0];
        }

        public ADODB.Connection gl_AdodcConnection()
        {
            cnNach.ConnectionString = @"Provider=SQLOLEDB.1;Password=sql@12345;Persist Security Info=True;User ID=sa; Initial Catalog=NACH_TPSX;Data Source=MMSDCDB001"; //Uncomment while publishing 
            //cnNach.ConnectionString = @"Provider=SQLOLEDB.1;Password=admin@123;Persist Security Info=True;User ID=sa; Initial Catalog=NACH_UAT;Data Source=NACHSERVER"; //Uncomment while publishing            
            //cnNach.ConnectionString = ConfigurationManager.ConnectionStrings["NACH"].ConnectionString;
            cnNach.Open();
            return cnNach;
        }
              
        public void pr_RdOnlyRcrdSt(out ADODB.Recordset rsRdOnly, string SQL_RdOnly)
        {
            rsRdOnly = new ADODB.Recordset();
            rsRdOnly.ActiveConnection = gl_AdodcConnection();
            rsRdOnly.CursorType = ADODB.CursorTypeEnum.adOpenForwardOnly;
            rsRdOnly.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
            rsRdOnly.LockType = ADODB.LockTypeEnum.adLockReadOnly;
            rsRdOnly.Open(SQL_RdOnly);
        }
        public void gl_AdodcConnectionClose()
        {
            cnNach.Close();
        }
    }
}
