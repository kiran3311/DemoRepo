﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Web.Security;
using System.Configuration;
/// <summary>
/// Summary description for EncryptDecryptConnStr
/// </summary>
/// 

namespace NACH_Application
{
    public class EncryptDecryptConnStr
    {
        public EncryptDecryptConnStr()
        {
            EncryptConnString();
            //
            // TODO: Add constructor logic here
            //
        }
        public void EncryptConnString() 
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);    
            //ConfigurationSection section = config.GetSection(ConfigurationManager.ConnectionStrings["NACH_UAT"].ConnectionString);
            ConfigurationSection section = config.GetSection(ConfigurationManager.ConnectionStrings["NACHUAT_BKP"].ConnectionString); 
        }
    }
}