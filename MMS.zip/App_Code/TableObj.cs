﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserSession
/// </summary>
/// 
[Serializable]
public class TableObj
{
    public TableObj()
    {
    }
    //
    // TODO: Add constructor logic here
    //

    public string FLAGMASTER { get; set; }  
    
    }