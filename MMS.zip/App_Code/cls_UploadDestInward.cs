﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for cls_UploadDestInward
/// </summary>
public class cls_UploadDestInward
{
	public cls_UploadDestInward()
	{		
	}    
    public string col1 { get; set; }    
    
    //public string TXN_TYPE { get; set; }
    //public string TXN_DESCRIPTION { get; set; }
    //public string M_TRNCODE { get; set; }
    //public string AC_TYPE { get; set; }
    //public string M_FOLNMBR { get; set; }
    //public string M_ACNM { get; set; }
    //public string M_USRNM { get; set; }
    //public string M_AMOUNT { get; set; }
    //public string M_ITEMSEQNO { get; set; }
    //public string M_CHKSUM { get; set; }
    //public string M_ACNO { get; set; }
    //public string M_SPBKIFSC { get; set; }
    //public string M_USRNMBR { get; set; }
    //public string M_TRNREF { get; set; }
    //public string M_PRODTYPE { get; set; }
    //public string M_ADHRNMBR { get; set; }
    //public string M_UMRN { get; set; }
    //public string M_RETRUN { get; set; }
    //public string M_RESNCOD { get; set; }    
        
}