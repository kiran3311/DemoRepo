﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CurrentUserList
/// </summary>
public static class CurrentUserList
{
    private static List<int> _UserCodeList;

	static CurrentUserList()
	{
        _UserCodeList = new List<int>();
        _UserCodeList.Clear();
	}

    public static List<int> CurrentUserCodeList 
    {
        get
        {
            return _UserCodeList;
        }
    }

    public static bool Add(int UCode)
    {
        if (!_UserCodeList.Contains(UCode))
        {
            _UserCodeList.Add(UCode);
            return true;
        }
        return false;
    }
    public static bool Remove(int UCode)
    {
        if (_UserCodeList.Contains(UCode))
        {
            _UserCodeList.Remove(UCode);
            return true;
        }
        return false;
    }
    public static bool Contains(int UCode)
    {
        return _UserCodeList.Contains(UCode);
    }
    public static void Clear()
    {
        _UserCodeList.Clear();
    }

    public static string GetUserList_IN_STR()
    { 
        string Codes = string.Empty;
        foreach (int Ucode in _UserCodeList)
        {
            if (string.IsNullOrWhiteSpace(Codes))
                Codes = Ucode.ToString();
            else
                Codes += ("," + Ucode.ToString());
        }
        return Codes;
    }

    
}