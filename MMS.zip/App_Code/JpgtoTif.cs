﻿using ImageMagick;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for JpgtoTif
/// </summary>
public class JpgtoTif
{


    public void JpgToTifImage(string imgfile, string DestPath, int dpi, int quality)
    {
        string qstring = quality.ToString();
        var srcImg = System.Drawing.Image.FromFile(imgfile);
        string[] imageSource = imgfile.Split('.');

        //string newJTname = Path.GetFileNameWithoutExtension(imgfile);
        string newJTname = imageSource[0];
        string DestPath1 = DestPath;
        // int OgImgFileSize = OgImgFileSize + new FileInfo(imgfile).Length;

        using (MagickImage img = new MagickImage(imgfile))
        {
            img.Format = MagickFormat.Tiff;
            Density den = new Density(dpi);
            img.Density = den;
            if (quality == 100)
            {
                img.Settings.Compression = ImageMagick.CompressionMethod.JPEG;
            }
            else
            {
                img.Quality = quality;
            }
            //img.Depth = 8;
            img.Settings.ColorType = ImageMagick.ColorType.Grayscale;
            img.Settings.Compression = ImageMagick.CompressionMethod.JPEG;
            img.Write(DestPath1);
            //ComImgSize = ComImgSize + new FileInfo(DestPath1).Length;
        }
    }

}