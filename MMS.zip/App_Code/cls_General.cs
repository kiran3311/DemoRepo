﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Data;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
////using //Oracle.DataAccess.Client;
using Excel = Microsoft.Office.Interop.Excel;
using Aspose.Cells;
using System.Data.SqlClient;
using System.Configuration;

namespace NACH_Application
{
    public class cls_General
    {
        [DllImport(@"C:\WINDOWS\system32\EnDDll.dll", EntryPoint = "_nEncrypt@8", CharSet = CharSet.Ansi)]
        public static extern int EnFunc(string SourceFile, string DestFile);

        [DllImport(@"C:\WINDOWS\system32\EnDDll.dll", EntryPoint = "_checksum@4", CharSet = CharSet.Ansi)]
        public static extern string ChkSum(string DestFile);

        cls_DBConnection db = new cls_DBConnection(); 
       
        // Global Variabl Declaration for all tables
        public static string GL_NACHResetPWD
        {
            get
            {
                return GetNACHResetPWDFromSession().GL_NACHResetPWD;
            }
        }
        public static void SetNACHResetPWDInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHResetPWD"] = vUserObj;
        }
        public static UserObj GetNACHResetPWDFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHResetPWD"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHResetPWD"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }

        public static Boolean gl_DisplayFlag = false ;

        public static void SetUserObjInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["UserObj"] = vUserObj;
        }

        public static void SetUtilityIDInSession(UserObj vUtilityID)
        {           
            HttpContext.Current.Session["GL_NACHUtilityID"] = vUtilityID;
        }

         public static void SetUtilityCDInSession(UserObj vUtilityCd)
        {            
            HttpContext.Current.Session["GL_NACHUtilityCd"] = vUtilityCd;
        }

         public static void SetUtilityNameInSession(UserObj vUtilityName)
         {
             HttpContext.Current.Session["GL_NACHUtilityName"] = vUtilityName;
         }

         public static void SetNachEcsAccNoInSession(UserObj vEcsAccNo)
         {
             HttpContext.Current.Session["GL_NACHEcsAccNo"] = vEcsAccNo;
         }

         public static void SetNPCIUserNoInSession(UserObj vNpciUserNO)
         {
             HttpContext.Current.Session["GL_NPCIUserNo"] = vNpciUserNO;
         }

         public static void SetNPCIUserNameInSession(UserObj vNpciUserName)
         {
             HttpContext.Current.Session["GL_NPCIUserName"] = vNpciUserName;
         }

         public static void SetNPCIProductCodeInSession(UserObj vNpciProductCode)
         {
             HttpContext.Current.Session["GL_ProductCode"] = vNpciProductCode;
         }

         public static void SetMaxAmountInSession(UserObj vMaxAmount)
         {
             HttpContext.Current.Session["GL_MaxAmount"] = vMaxAmount;
         }

         public static void SetProductNameInSession(UserObj vProductname)
         {
             HttpContext.Current.Session["GL_Product"] = vProductname;
         }

         public static UserObj GetUtilityIDFromSession()
        {            
            if (HttpContext.Current.Session["GL_NACHUtilityID"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUtilityID"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }         
        }

         public static UserObj GetUtilityCDFromSession()
        {            
            if (HttpContext.Current.Session["GL_NACHUtilityCd"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUtilityCd"];
            }
            else
            {
                UserObj utilityCD = new UserObj();
                return utilityCD;
            }            
        }

        public static UserObj GetUserObjFromSession()
        {
            UserObj userobj = new UserObj();

            if (HttpContext.Current.Session["UserObj"] != null)
            {
                return (UserObj)HttpContext.Current.Session["UserObj"];
            }
            else
            {              
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Session.Contents.RemoveAll();
                System.Web.Security.FormsAuthentication.SignOut();
                //HttpContext.Current.Response.Redirect("~/Login.aspx");
                HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["PaymentSystem_URL"]);
                return userobj;
            }           
            
        }

        public static UserObj GetUtilityNameFromSession()
        {            
            if (HttpContext.Current.Session["GL_NACHUtilityName"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUtilityName"];
            }
            else
            {
                UserObj utilityName = new UserObj();
                return utilityName;
            }
           
        }

        public static UserObj GetNachEcsAccNoFromSession()
        {            
            if (HttpContext.Current.Session["GL_NACHEcsAccNo"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHEcsAccNo"];
            }
            else
            {
                UserObj uEcsAccNo = new UserObj();
                return uEcsAccNo;
            }
         
        }

        public static UserObj GetNPCIUserNoFromSession()
        {            
            if (HttpContext.Current.Session["GL_NPCIUserNo"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NPCIUserNo"];
            }
            else
            {
                UserObj uNPCIUserNo = new UserObj();
                return uNPCIUserNo;
            }
           
        }

        public static UserObj GetNPCIUserCodeFromSession()
        {
            if (HttpContext.Current.Session["GL_NPCIUserCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NPCIUserCode"];
            }
            else
            {
                UserObj uNPCIUserCode = new UserObj();
                return uNPCIUserCode;
            }
        }

        public static UserObj GetNPCIUserNameFromSession()
        {            
            if (HttpContext.Current.Session["GL_NPCIUserName"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NPCIUserName"];
            }
            else
            {
                UserObj uNPCIUserName = new UserObj();
                return uNPCIUserName;
            }
         
        }

        public static UserObj GetNPCIProductCodeFromSession()
        {            
            if (HttpContext.Current.Session["GL_ProductCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ProductCode"];
            }
            else
            {
                UserObj uNPCIProductCode = new UserObj();
                return uNPCIProductCode;
            }
         
        }

        public static UserObj GetMaxAmountFromSession()
        {            
            if (HttpContext.Current.Session["GL_MaxAmount"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_MaxAmount"];
            }
            else
            {
                UserObj uMaxAmount = new UserObj();
                return uMaxAmount;
            }            
        }

        public static UserObj GetProductNameFromSession()
        {            
            if (HttpContext.Current.Session["GL_Product"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Product"];
            }
            else
            {
                UserObj uProductName = new UserObj();
                return uProductName;
            }
         
        }

        /*public void SetGlobalDtlsInSession(GlobalVarObj vGlobalVarObj)
        {
            HttpContext.Current.Session["GlobalVarObj"] = vGlobalVarObj;
        }*/

        public static void SetTableObjInSession(TableObj vTableObj)
        {
            HttpContext.Current.Session["TableObj"] = vTableObj;
        }

        public static TableObj GetTableObjFromSession()
        {
            return (TableObj)HttpContext.Current.Session["TableObj"];
        }

        //---------------------------------------------        
        public static string GL_FlagMaster
        {
            get
            {
                return GetTableObjFromSession().FLAGMASTER;
            }
        }
        
        // by sumedh----
        public static SqlDataReader GL_drFirstEntry; 
        //--------------
        //Global variable for Parameters
        public static void SetCompanyObjInSession(CompanyObj vCompanyObj)
        {
            HttpContext.Current.Session["CompanyObj"] = vCompanyObj;
        }

        public static CompanyObj GetCompanyObjFromSession()
        {
            CompanyObj compobj = new CompanyObj();

            if (HttpContext.Current.Session["CompanyObj"] != null)
            {
                return (CompanyObj)HttpContext.Current.Session["CompanyObj"];
            }
            else
            {               
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Session.Contents.RemoveAll();
                System.Web.Security.FormsAuthentication.SignOut();
                //HttpContext.Current.Response.Redirect("~/Login.aspx");                
                HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["PaymentSystem_URL"]);
                return compobj;
            }           
        }
                
        public static string GL_CmpnyNm
        {
            get
            {
                return GetCompanyObjFromSession().CompanyName;
            }
        }
        public static string GL_CmpnyCd
        {
            get
            {
                return GetCompanyObjFromSession().CompanyCode;
            }
        }
       
        public static long GL_UsrCd
        {
            get
            {
                return Convert.ToInt32(GetUserObjFromSession().UserCode);
            }
        }

        public static string GL_UsrNm
        {
            get
            {              
              return GetUserObjFromSession().UserName;               
            }
        }

        //======14062014=============

        public static string GL_NACHUtilityID
        {
            get
            {
                return GetUtilityIDFromSession().GL_NACHUtilityID;
            }
        }

        public static string GL_NACHUtilityCd
        {
            get
            {
                return GetUtilityCDFromSession().GL_NACHUtilityCd;
            }
        }

        public static string GL_NACHUtilityName
        {
            get
            {
                return GetUtilityNameFromSession().GL_NACHUtilityName;
            }
        }

        public static string GL_NACHEcsAccNo
        {
            get
            {
                return GetNachEcsAccNoFromSession().GL_NACHEcsAccNo;
            }
        }

        public static string GL_NPCIUserNo
        {
            get
            {
                return GetNPCIUserNoFromSession().GL_NPCIUserNo;
            }
        }

        public static string GL_NPCIUserCode
        {
            get
            {
                return GetNPCIUserNoFromSession().GL_NPCIUserCode;
            }
        }

        public static string GL_NPCIUserName
        {
            get
            {
                return GetNPCIUserNameFromSession().GL_NPCIUserName;
            }
        }

        public static string GL_ProductCode
        {
            get
            {
                return GetNPCIProductCodeFromSession().GL_ProductCode;
            }
        }

        public static string GL_MaxAmount
        {
            get
            {
                return GetMaxAmountFromSession().GL_MaxAmount;
            }
        }

        public static string GL_Product
        {
            get
            {
                return GetProductNameFromSession().GL_Product;
            }
        }

        public static string GL_BranchID
        {
            get
            {
                return GetUserObjFromSession().BranchID;
            }
        }
        public static string GL_BranchName
        {
            get
            {
                return GetUserObjFromSession().BranchName;
            }
        }
        public static string GL_SoleID
        {
            get
            {
                return GetUserObjFromSession().SoleID;
            }
        }
       
        //------For downloading -------
       
        public void CreateFolder(string FolderPTH)
        {

            if (!Directory.Exists(FolderPTH))
            {
                string[] Folders = FolderPTH.Split('\\');
                Directory.SetCurrentDirectory("\\");
                for (int i = 1; i < Folders.Length; i++)
                {
                    if (!Directory.Exists(Folders[i]))
                    {
                        Directory.CreateDirectory(Folders[i]);
                        Directory.SetCurrentDirectory(Folders[i]);
                    }
                    else
                    { Directory.SetCurrentDirectory(Folders[i]); }
                }
            }
        }
        
        public Boolean ParseString(string str)
        {

            bool boolValue;
            Int32 intValue;
            Int64 bigintValue;
            decimal doubleValue;
            DateTime dateValue;

            // Place checks higher in if-else statement to give higher priority to type.

            if (bool.TryParse(str, out boolValue))
                return true;
            else if (Int32.TryParse(str, out intValue))
                return true;
            else if (Int64.TryParse(str, out bigintValue))
                return true;
            else if (decimal.TryParse(str, out doubleValue))
                return true;
            else if (DateTime.TryParse(str, out dateValue))
                return true;
            else
                return false;

        }

        public void pr_LogFileUpdation(string m_text, string m_txtFileNm, string m_startFlag = null, string m_OptnName = null)
        {

            StreamWriter m_strWr;

            if (!File.Exists(m_txtFileNm))
                m_strWr = new StreamWriter(m_txtFileNm);
            else
                m_strWr = File.AppendText(m_txtFileNm);

            if (m_startFlag == "S")
                m_strWr.WriteLine(m_OptnName);
            else if (m_startFlag == "" || m_startFlag == null)
                m_strWr.WriteLine(m_text);
            else if (m_startFlag == "E")
                m_strWr.WriteLine("********************************************");
            m_strWr.Close();

        }
          
        public void pr_ExcelReport(string m_SqlStr, string m_ExcelFileName, string m_ExcelSheetName, string m_StrHeader = null, string m_StrHeader1 = null)
        {            
            Excel.Application xlsApp;
            Excel.Workbook xlsWorkBook;
            Excel.Worksheet xlsWorkSheet;
            Excel.Range xlsRange;
            int m_RW, m_Col, m_FirstRW;
            string m_colName, m_ExportFileName;
            ADODB.Recordset rs = new ADODB.Recordset();
            m_ExportFileName = "";
            m_ExportFileName = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + m_ExcelFileName;
            try
            {               
                if (!File.Exists(m_ExportFileName))
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Add(Type.Missing);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsApp.Worksheets["Sheet1"];
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                else
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Open(m_ExportFileName);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsWorkBook.Worksheets.Add();                   
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                
                if (rs.State == 1) rs.Close();
                db.pr_RdOnlyRcrdSt(out rs, m_SqlStr);

                m_RW = 1;
                m_Col = 1;

                if (m_StrHeader != null && m_StrHeader != "")
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader;

                    m_colName = xlsWorkSheet.Columns[rs.Fields.Count].ToString();
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count]);
                    m_colName = m_colName.Substring(1, 1);
                    xlsWorkSheet.Range["A1:" + m_colName + "1"].MergeCells = true;
                    xlsRange = xlsWorkSheet.get_Range("A1", m_colName + m_RW);
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_Col = 1;
                if (m_StrHeader1 != null && m_StrHeader1 != "")
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader1;

                    m_colName = xlsWorkSheet.Columns[rs.Fields.Count].ToString();
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count]);
                    m_colName = m_colName.Substring(1, 1);
                    xlsWorkSheet.Range["A" + m_RW + ":" + m_colName + m_RW].MergeCells = true;
                    xlsRange = xlsWorkSheet.get_Range("A" + m_RW, m_colName + m_RW);
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                if (m_StrHeader == null && m_StrHeader1 == null)
                {
                    m_RW = 1;
                }
                else
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                }
                m_Col = 1;
                for (m_Col = 1; m_Col <= rs.Fields.Count; m_Col++)
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = rs.Fields[m_Col - 1].Name;
                    m_colName = xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count].ToString();
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count]);
                    m_colName = m_colName.Substring(1, 1);
                    xlsRange = xlsWorkSheet.get_Range(m_colName + m_RW, m_colName + m_RW);
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                m_colName = xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count].ToString();
                m_colName = Convert.ToString(xlsWorkSheet.Columns[xlsWorkSheet.UsedRange.Columns.Count]);
                m_colName = m_colName.Substring(1, 1);
                xlsRange = xlsWorkSheet.get_Range("A" + m_RW, m_colName + m_RW);
                xlsRange.Font.Bold = true;
                xlsRange.HorizontalAlignment = Excel.Constants.xlCenter;
                xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_FirstRW = m_RW;

                if (rs.EOF == false)
                {
                    xlsRange = xlsWorkSheet.get_Range("A" + m_RW, "A" + (m_RW + rs.RecordCount));
                    xlsRange.CopyFromRecordset(rs, Type.Missing, Type.Missing);
                }
                xlsWorkSheet.Rows.EntireColumn.AutoFit();

                db.gl_AdodcConnectionClose();

                int m_xlSheetCount = xlsWorkBook.Sheets.Count;

                foreach (Excel.Worksheet sheet in xlsWorkBook.Sheets)
                {
                    for (int i = 1; i <= m_xlSheetCount; i++)
                    {
                        if (sheet.Name.ToLower() == "sheet" + i)
                        {
                            sheet.Delete();
                            break;
                        }
                    }
                }

                xlsWorkSheet = (Excel.Worksheet)xlsWorkBook.Sheets[1];
                xlsWorkSheet.Activate();

                if (File.Exists(@m_ExportFileName))
                {
                    xlsWorkBook.Save();
                }
                else
                {
                    xlsWorkBook.SaveAs(@m_ExportFileName, Excel.XlFileFormat.xlWorkbookDefault);
                }
                xlsWorkBook.Close();
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlsApp);
                xlsApp = null;
                GC.Collect();
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {                
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                return;
            }
        }
        
        public void pr_ExcelReport(string m_SqlStr, string m_ExcelFileName, string m_ExcelSheetName, string m_StrHeader = null, string m_StrHeader1 = null, Boolean m_asposeFlag = false, Boolean M_TotalData = false, string m_sumCol = null)
        {           
            double m_Sum, m_Sum1, m_Sum2, m_Sum3, m_Sum4, m_Sum5, m_Sum6, m_SumC, m_SumD;
            Excel.Application xlsApp;
            Excel.Workbook xlsWorkBook;
            Excel.Worksheet xlsWorkSheet;
            Excel.Range xlsRange;
            Excel.Range xlsRange1;
            Excel.Range xlsRange2;
            Excel.Range xlsRange3;
            Excel.Range xlsRange4;
            Excel.Range xlsRange5;
            Excel.Range xlsRange6;
            Excel.Range xlsRangeC;
            Excel.Range xlsRangeD;
            int m_RW, m_Col, m_FirstRW;
            string m_colName, m_ExportFileName;
            ADODB.Recordset rs = new ADODB.Recordset();
            m_ExportFileName = "";
            m_ExportFileName = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + m_ExcelFileName;
            try
            {
                if (!File.Exists(m_ExportFileName))
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Add(Type.Missing);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsApp.Worksheets["Sheet1"];
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                else
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Open(m_ExportFileName);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsWorkBook.Worksheets.Add();
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                if (rs.State == 1) rs.Close();
                db.pr_RdOnlyRcrdSt(out rs, m_SqlStr);

                m_RW = 1;
                m_Col = 1;

                if (m_StrHeader != null && m_StrHeader != "")
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader;
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[rs.Fields.Count]);
                    xlsWorkSheet.Range["A1:I1"].MergeCells = true;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[1, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_Col = 1;
                if (m_StrHeader1 != null && m_StrHeader1 != "")
                {
                    xlsWorkSheet.Range["A2:I2"].MergeCells = true;
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader1;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                if (m_StrHeader == null && m_StrHeader1 == null)
                {
                    m_RW = 1;
                }
                else
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                }
                m_Col = 1;
                for (m_Col = 1; m_Col <= rs.Fields.Count; m_Col++)
                {

                    xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, m_Col];
                    xlsWorkSheet.Cells[m_RW, m_Col] = rs.Fields[m_Col - 1].Name;
                    if (m_Col == 3)
                    {
                        xlsRange.ColumnWidth = 12.57;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 5)
                    {
                        xlsRange.ColumnWidth = 34;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 9)
                    {
                        xlsRange.ColumnWidth = 19.50;
                        xlsRange.WrapText = true;
                    }
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_FirstRW = m_RW;

                if (rs.EOF == false)
                {                   
                    xlsRange = xlsWorkSheet.get_Range("A" + m_RW, "A" + (m_RW + rs.RecordCount));
                    xlsRange.CopyFromRecordset(rs, Type.Missing, Type.Missing);
                }
                
                if (M_TotalData == true)
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                                   
                    if (m_sumCol == "5")
                    {
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];
                        xlsRange5 = xlsWorkSheet.Range["J:J"];
                        xlsRange6 = xlsWorkSheet.Range["K:K"];
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);                        
                        m_Sum5 = xlsApp.WorksheetFunction.Sum(xlsRange5);
                        m_Sum6 = xlsApp.WorksheetFunction.Sum(xlsRange6);
                        
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                        
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Value = m_Sum5.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Value = m_Sum6.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Font.Bold = true;
                       
                    }
                    else if (m_sumCol == "3")
                    {
                        xlsRangeC = xlsWorkSheet.Range["C:C"];
                        xlsRangeD = xlsWorkSheet.Range["D:D"];
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];                       
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);
                        m_SumC = xlsApp.WorksheetFunction.Sum(xlsRangeC);
                        m_SumD = xlsApp.WorksheetFunction.Sum(xlsRangeD);
                        
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Font.Bold = true;

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Value = m_SumC.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_SumD.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                    }
                   
                }
                                
                for (m_FirstRW = 1; m_FirstRW <= xlsWorkSheet.UsedRange.Rows.Count; m_FirstRW++)
                {
                    for (m_Col = 1; m_Col <= xlsWorkSheet.UsedRange.Columns.Count; m_Col++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_FirstRW, m_Col];
                        if (m_Col == 5)
                        {
                            xlsRange.ColumnWidth = 34;
                            xlsRange.WrapText = true;
                        }
                        if (m_Col == 9)
                        {
                            xlsRange.ColumnWidth = 19.50;
                            xlsRange.WrapText = true;
                        }

                        xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                    }
                }
                xlsWorkSheet.Rows.EntireColumn.AutoFit();

                db.gl_AdodcConnectionClose();


                int m_xlSheetCount = xlsWorkBook.Sheets.Count;

                foreach (Excel.Worksheet sheet in xlsWorkBook.Sheets)
                {
                    for (int i = 1; i <= m_xlSheetCount; i++)
                    {
                        if (sheet.Name.ToLower() == "sheet" + i)
                        {
                            sheet.Delete();
                            break;
                        }
                    }
                }
                xlsWorkSheet = (Excel.Worksheet)xlsWorkBook.Sheets[1];
                xlsWorkSheet.Activate();
                if (File.Exists(@m_ExportFileName))
                {
                    xlsWorkBook.Save();
                }
                else
                {
                    xlsWorkBook.SaveAs(@m_ExportFileName, Excel.XlFileFormat.xlWorkbookDefault);
                }
                xlsWorkBook.Close();
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlsApp);
                xlsApp = null;
                GC.Collect();
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                if (m_asposeFlag == true)
                {
                    Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(@m_ExportFileName);
                    ////// ////Save the pdf file.
                    wb.Worksheets[0].PageSetup.LeftMargin = 0.75;
                    wb.Worksheets[0].PageSetup.RightMargin = 0.5;
                    wb.Worksheets[0].PageSetup.TopMargin = 0.75;
                    wb.Worksheets[0].PageSetup.BottomMargin = 0.5;
                    wb.Worksheets[0].PageSetup.PaperSize = Aspose.Cells.PaperSizeType.PaperA4;
                    wb.Worksheets[0].PageSetup.Orientation = Aspose.Cells.PageOrientationType.Landscape;
                    wb.Save(@m_ExportFileName.Replace(".xls", ".pdf"), saveFormat: Aspose.Cells.SaveFormat.Pdf);
                }
            }
            catch (Exception ex)
            {  
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                return;
            }
        }

        public void pr_ExcelReport(ADODB.Recordset rs, string m_ExcelFileName, string m_ExcelSheetName, string m_StrHeader = null, string m_StrHeader1 = null, Boolean m_asposeFlag = false, Boolean M_TotalData = false, string m_sumCol = null)
        {
            double m_Sum, m_Sum1, m_Sum2, m_Sum3, m_Sum4, m_Sum5, m_Sum6, m_SumC, m_SumD;
            Excel.Application xlsApp;
            Excel.Workbook xlsWorkBook;
            Excel.Worksheet xlsWorkSheet;
            Excel.Range xlsRange;
            Excel.Range xlsRange1;
            Excel.Range xlsRange2;
            Excel.Range xlsRange3;
            Excel.Range xlsRange4;
            Excel.Range xlsRange5;
            Excel.Range xlsRange6;
            Excel.Range xlsRangeC;
            Excel.Range xlsRangeD;
            int m_RW, m_Col, m_FirstRW;
            string m_colName, m_ExportFileName;
            m_ExportFileName = "";
            m_ExportFileName = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + m_ExcelFileName;
            try
            {
                if (!File.Exists(m_ExportFileName))
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Add(Type.Missing);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsApp.Worksheets["Sheet1"];
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                else
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Open(m_ExportFileName);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsWorkBook.Worksheets.Add();
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }

                m_RW = 1;
                m_Col = 1;

                if (m_StrHeader != null && m_StrHeader != "")
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader;
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[rs.Fields.Count]);
                    xlsWorkSheet.Range["A1:I1"].MergeCells = true;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[1, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_Col = 1;
                if (m_StrHeader1 != null && m_StrHeader1 != "")
                {
                    xlsWorkSheet.Range["A2:I2"].MergeCells = true;
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader1;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                if (m_StrHeader == null && m_StrHeader1 == null)
                {
                    m_RW = 1;
                }
                else
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                }
                m_Col = 1;
                for (m_Col = 1; m_Col <= rs.Fields.Count; m_Col++)
                {
                    xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, m_Col];
                    xlsWorkSheet.Cells[m_RW, m_Col] = rs.Fields[m_Col - 1].Name;
                    if (m_Col == 3)
                    {
                        xlsRange.ColumnWidth = 12.57;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 5)
                    {
                        xlsRange.ColumnWidth = 34;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 9)
                    {
                        xlsRange.ColumnWidth = 19.50;
                        xlsRange.WrapText = true;
                    }
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_FirstRW = m_RW;

                if (rs.EOF == false)
                {
                    xlsRange = xlsWorkSheet.get_Range("A" + m_RW);
                    xlsRange.CopyFromRecordset(rs, Type.Missing, Type.Missing);
                }

                if (M_TotalData == true)
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;

                    if (m_sumCol == "5")
                    {
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];
                        xlsRange5 = xlsWorkSheet.Range["J:J"];
                        xlsRange6 = xlsWorkSheet.Range["K:K"];
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);

                        m_Sum5 = xlsApp.WorksheetFunction.Sum(xlsRange5);
                        m_Sum6 = xlsApp.WorksheetFunction.Sum(xlsRange6);

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Value = m_Sum5.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Value = m_Sum6.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Font.Bold = true;

                    }
                    else if (m_sumCol == "3")
                    {
                        xlsRangeC = xlsWorkSheet.Range["C:C"];
                        xlsRangeD = xlsWorkSheet.Range["D:D"];
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);
                        m_SumC = xlsApp.WorksheetFunction.Sum(xlsRangeC);
                        m_SumD = xlsApp.WorksheetFunction.Sum(xlsRangeD);
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Font.Bold = true;

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Value = m_SumC.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_SumD.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                    }

                }

                for (m_FirstRW = 1; m_FirstRW <= xlsWorkSheet.UsedRange.Rows.Count; m_FirstRW++)
                {
                    for (m_Col = 1; m_Col <= xlsWorkSheet.UsedRange.Columns.Count; m_Col++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_FirstRW, m_Col];
                        if (m_Col == 5)
                        {
                            xlsRange.ColumnWidth = 34;
                            xlsRange.WrapText = true;
                        }
                        if (m_Col == 9)
                        {
                            xlsRange.ColumnWidth = 19.50;
                            xlsRange.WrapText = true;
                        }

                        xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                    }
                }
                xlsWorkSheet.Rows.EntireColumn.AutoFit();

                int m_xlSheetCount = xlsWorkBook.Sheets.Count;

                foreach (Excel.Worksheet sheet in xlsWorkBook.Sheets)
                {
                    for (int i = 1; i <= m_xlSheetCount; i++)
                    {
                        if (sheet.Name.ToLower() == "sheet" + i)
                        {
                            sheet.Delete();
                            break;
                        }
                    }
                }
                xlsWorkSheet = (Excel.Worksheet)xlsWorkBook.Sheets[1];
                xlsWorkSheet.Activate();
                if (File.Exists(@m_ExportFileName))
                {
                    xlsWorkBook.Save();
                }
                else
                {
                    xlsWorkBook.SaveAs(@m_ExportFileName, Excel.XlFileFormat.xlWorkbookDefault);
                }
                xlsWorkBook.Close();
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlsApp);
                xlsApp = null;
                GC.Collect();
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                if (m_asposeFlag == true)
                {
                    Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(@m_ExportFileName);
                    ////// ////Save the pdf file.
                    wb.Worksheets[0].PageSetup.LeftMargin = 0.75;
                    wb.Worksheets[0].PageSetup.RightMargin = 0.5;
                    wb.Worksheets[0].PageSetup.TopMargin = 0.75;
                    wb.Worksheets[0].PageSetup.BottomMargin = 0.5;
                    wb.Worksheets[0].PageSetup.PaperSize = Aspose.Cells.PaperSizeType.PaperA4;
                    wb.Worksheets[0].PageSetup.Orientation = Aspose.Cells.PageOrientationType.Landscape;
                    wb.Save(@m_ExportFileName.Replace(".xls", ".pdf"), saveFormat: Aspose.Cells.SaveFormat.Pdf);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                return;
            }
        }


      

        public void Pr_ExcelReportGenerate(ADODB.Recordset rs, string m_ExcelFileName, string m_ExcelSheetName, string m_StrHeader = null, string m_StrHeader1 = null, Boolean m_asposeFlag = false, Boolean M_TotalData = false, string m_sumCol = null, string m_Utility = null)
        {
            double m_Sum, m_Sum1, m_Sum2, m_Sum3, m_Sum4, m_Sum5, m_Sum6, m_SumC, m_SumD;
            Excel.Application xlsApp;
            Excel.Workbook xlsWorkBook;
            Excel.Worksheet xlsWorkSheet;
            Excel.Range xlsRange;
            Excel.Range xlsRange1;
            Excel.Range xlsRange2;
            Excel.Range xlsRange3;
            Excel.Range xlsRange4;
            Excel.Range xlsRange5;
            Excel.Range xlsRange6;
            Excel.Range xlsRangeC;
            Excel.Range xlsRangeD;
            int m_RW, m_Col, m_FirstRW;
            string m_colName, m_ExportFileName;
            m_ExportFileName = "";
            m_ExportFileName = cls_General.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy") + "\\" + m_ExcelFileName;
            try
            {
                if (!File.Exists(m_ExportFileName))
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Add(Type.Missing);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsApp.Worksheets["Sheet1"];
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }
                else
                {
                    xlsApp = new Excel.Application();
                    xlsWorkBook = xlsApp.Workbooks.Open(m_ExportFileName);
                    xlsWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlsWorkBook.Worksheets.Add();
                    xlsWorkSheet.Name = m_ExcelSheetName;
                }

                m_RW = 1;
                m_Col = 1;

                if (m_StrHeader != null && m_StrHeader != "")
                {
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader;
                    m_colName = Convert.ToString(xlsWorkSheet.Columns[rs.Fields.Count]);
                    xlsWorkSheet.Range["A1:I1"].MergeCells = true;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[1, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_Col = 1;
                if (m_StrHeader1 != null && m_StrHeader1 != "")
                {
                    xlsWorkSheet.Range["A2:I2"].MergeCells = true;
                    xlsWorkSheet.Cells[m_RW, m_Col] = m_StrHeader1;
                    for (int i = 1; i <= rs.Fields.Count; i++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, i];
                        xlsRange.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);
                    }
                }
                if (m_StrHeader == null && m_StrHeader1 == null)
                {
                    m_RW = 1;
                }
                else
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                }
                m_Col = 1;
                for (m_Col = 1; m_Col <= rs.Fields.Count; m_Col++)
                {

                    xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_RW, m_Col];
                    xlsWorkSheet.Cells[m_RW, m_Col] = rs.Fields[m_Col - 1].Name;
                    if (m_Col == 3)
                    {
                        xlsRange.ColumnWidth = 12.57;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 5)
                    {
                        xlsRange.ColumnWidth = 34;
                        xlsRange.WrapText = true;
                    }
                    if (m_Col == 9)
                    {
                        xlsRange.ColumnWidth = 19.50;
                        xlsRange.WrapText = true;
                    }
                    xlsRange.Font.Bold = true;
                    xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                }
                m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                m_FirstRW = m_RW;

                if (rs.EOF == false)
                {
                    xlsRange = xlsWorkSheet.get_Range("A" + m_RW);
                    xlsRange.CopyFromRecordset(rs, Type.Missing, Type.Missing);
                }

                if (M_TotalData == true)
                {
                    m_RW = xlsWorkSheet.UsedRange.Rows.Count + 1;
                    if (m_sumCol == "5")
                    {
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];
                        xlsRange5 = xlsWorkSheet.Range["J:J"];
                        xlsRange6 = xlsWorkSheet.Range["K:K"];
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);
                        m_Sum5 = xlsApp.WorksheetFunction.Sum(xlsRange5);
                        m_Sum6 = xlsApp.WorksheetFunction.Sum(xlsRange6);
                        
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Value = m_Sum5.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 10], xlsWorkSheet.Cells[m_RW, 10]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Value = m_Sum6.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 11], xlsWorkSheet.Cells[m_RW, 11]].Font.Bold = true;
                    }
                    else if (m_sumCol == "3")
                    {
                        xlsRangeC = xlsWorkSheet.Range["C:C"];
                        xlsRangeD = xlsWorkSheet.Range["D:D"];
                        xlsRange = xlsWorkSheet.Range["E:E"];
                        xlsRange1 = xlsWorkSheet.Range["F:F"];
                        xlsRange2 = xlsWorkSheet.Range["G:G"];
                        xlsRange3 = xlsWorkSheet.Range["H:H"];
                        xlsRange4 = xlsWorkSheet.Range["I:I"];
                        m_Sum = xlsApp.WorksheetFunction.Sum(xlsRange);
                        m_Sum1 = xlsApp.WorksheetFunction.Sum(xlsRange1);
                        m_Sum2 = xlsApp.WorksheetFunction.Sum(xlsRange2);
                        m_Sum3 = xlsApp.WorksheetFunction.Sum(xlsRange3);
                        m_Sum4 = xlsApp.WorksheetFunction.Sum(xlsRange4);
                        m_SumC = xlsApp.WorksheetFunction.Sum(xlsRangeC);
                        m_SumD = xlsApp.WorksheetFunction.Sum(xlsRangeD);

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Value = "Total";
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 2], xlsWorkSheet.Cells[m_RW, 2]].Font.Bold = true;

                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Value = m_Sum.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 5], xlsWorkSheet.Cells[m_RW, 5]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Value = m_Sum1.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 6], xlsWorkSheet.Cells[m_RW, 6]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Value = m_Sum2.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 7], xlsWorkSheet.Cells[m_RW, 7]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Value = m_Sum3.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 8], xlsWorkSheet.Cells[m_RW, 8]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Value = m_Sum4.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 9], xlsWorkSheet.Cells[m_RW, 9]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Value = m_SumC.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 3], xlsWorkSheet.Cells[m_RW, 3]].Font.Bold = true;
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Value = m_SumD.ToString();
                        xlsWorkSheet.Range[xlsWorkSheet.Cells[m_RW, 4], xlsWorkSheet.Cells[m_RW, 4]].Font.Bold = true;
                    }
                }
                
                for (m_FirstRW = 1; m_FirstRW <= xlsWorkSheet.UsedRange.Rows.Count; m_FirstRW++)
                {
                    for (m_Col = 1; m_Col <= xlsWorkSheet.UsedRange.Columns.Count; m_Col++)
                    {
                        xlsRange = (Excel.Range)xlsWorkSheet.Cells[m_FirstRW, m_Col];
                        if (m_Col == 5)
                        {
                            xlsRange.ColumnWidth = 34;
                            xlsRange.WrapText = true;
                        }
                        if (m_Col == 9)
                        {
                            xlsRange.ColumnWidth = 19.50;
                            xlsRange.WrapText = true;
                        }

                        xlsRange.BorderAround(Type.Missing, Excel.XlBorderWeight.xlThin, Excel.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                    }
                }
                xlsWorkSheet.Rows.EntireColumn.AutoFit();

                int m_xlSheetCount = xlsWorkBook.Sheets.Count;

                foreach (Excel.Worksheet sheet in xlsWorkBook.Sheets)
                {
                    for (int i = 1; i <= m_xlSheetCount; i++)
                    {
                        if (sheet.Name.ToLower() == "sheet" + i)
                        {
                            sheet.Delete();
                            break;
                        }
                    }
                }
                xlsWorkSheet = (Excel.Worksheet)xlsWorkBook.Sheets[1];
                xlsWorkSheet.Activate();
                if (File.Exists(@m_ExportFileName))
                {
                    xlsWorkBook.Save();
                }
                else
                {
                    xlsWorkBook.SaveAs(@m_ExportFileName, Excel.XlFileFormat.xlWorkbookDefault);
                }
                xlsWorkBook.Close();
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlsApp);
                xlsApp = null;
                GC.Collect();
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }

                if (m_asposeFlag == true)
                {
                    if (m_Utility.ToString().ToUpper() != "ALL")
                    {
                        Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(@m_ExportFileName);
                        //// ////Save the pdf file.
                        wb.Worksheets[0].PageSetup.LeftMargin = 0.75;
                        wb.Worksheets[0].PageSetup.RightMargin = 0.5;
                        wb.Worksheets[0].PageSetup.TopMargin = 0.75;
                        wb.Worksheets[0].PageSetup.BottomMargin = 0.5;
                        
                        wb.Worksheets[0].PageSetup.PaperSize = PaperSizeType.PaperA4;
                        wb.Worksheets[0].PageSetup.Orientation = PageOrientationType.Landscape;
                        wb.Save(@m_ExportFileName.Replace(".xls", ".pdf"), SaveFormat.Pdf);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {
                    if (!string.IsNullOrEmpty(p.ProcessName))
                    {
                        try
                        {
                            p.Kill();
                        }
                        catch { }
                    }
                }
                return;
            }
        }
      
       // For session timeout 
        public static UserObj GetUserNameFromSession()
        {            
            if (HttpContext.Current.Session["GL_UserName"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UserName"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_UserName
        {
            get
            {
                return GetUserNameFromSession().GL_UserName;
            }
        }
        public static void SetUserNameInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UserName"] = vUserObj;
        }
        public static UserObj GetUserPwdFromSession()
        {
            if (HttpContext.Current.Session["GL_UserPwd"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UserPwd"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_UserPwd
        {
            get
            {
                return GetUserPwdFromSession().GL_UserPwd;
            }
        }
        public static void SetUserPwdInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UserPwd"] = vUserObj;
        }
        //--------------------
        public static UserObj GetUserCodeFromSession()
        {          
            if (HttpContext.Current.Session["GL_UserCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UserCode"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_UserCode
        {
            get
            {
                return GetUserCodeFromSession().GL_UserCode;
            }
        }
        public static void SetUserCodeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UserCode"] = vUserObj;
        }
        
        //------------
        public static UserObj GetCompanySelectedFromSession()
        {            
            if (HttpContext.Current.Session["GL_CompanySelected"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_CompanySelected"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }           
        }
        public static bool GL_CompanySelected
        {
            get
            {
                return GetCompanySelectedFromSession().GL_CompanySelected;
            }
        }
        public static void SetCompanySelectedInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_CompanySelected"] = vUserObj;
        }
        //-------------
        public static UserObj GetSystmDtFromSession()
        {            
            if (HttpContext.Current.Session["GL_SystmDt"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_SystmDt"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_SystmDt
        {
            get
            {
                return GetSystmDtFromSession().GL_SystmDt;
            }
        }
        public static void SetSystmDtInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_SystmDt"] = vUserObj;
        }
        //--------------
        public static UserObj GetReportPathFromSession()
        {            
            if (HttpContext.Current.Session["GL_ReportPath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ReportPath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_ReportPath
        {
            get
            {
                return GetReportPathFromSession().GL_ReportPath;
            }
        }
        public static void SetReportPathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ReportPath"] = vUserObj;
        }
        //----------------
        public static UserObj GetUploadPathFromSession()
        {
            if (HttpContext.Current.Session["GL_UploadPath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UploadPath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_UploadPath
        {
            get
            {
                return GetUploadPathFromSession().GL_UploadPath;
            }
        }
        public static void SetUploadPathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UploadPath"] = vUserObj;
        }
        //--------------        
        public static UserObj GetBatchFromSession()
        {            
            if (HttpContext.Current.Session["GL_Batch"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Batch"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Batch
        {
            get
            {
                return GetBatchFromSession().GL_Batch;
            }
        }
        public static void SetBatchInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_Batch"] = vUserObj;
        }
        //----------------
        public static UserObj GetMandateDataFromSession()
        {            
            if (HttpContext.Current.Session["GL_MandateData"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_MandateData"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_MandateData
        {
            get
            {
                return GetMandateDataFromSession().GL_MandateData;
            }
        }
        public static void SetMandateDataInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_MandateData"] = vUserObj;
        }
        //-----------------
        public static UserObj GetInwardFromSession()
        {            
            if (HttpContext.Current.Session["GL_Inward"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Inward"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Inward
        {
            get
            {
                return GetInwardFromSession().GL_Inward;
            }
        }
        public static void SetInwardInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_Inward"] = vUserObj;
        }
        //----------------
        public static UserObj GetOutwardFromSession()
        {            
            if (HttpContext.Current.Session["GL_Outward"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Outward"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Outward
        {
            get
            {
                return GetOutwardFromSession().GL_Outward;
            }
        }
        public static void SetOutwardInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_Outward"] = vUserObj;
        }
        //------------------
        public static UserObj GetNACHBranchMasterFromSession()
        {          
            if (HttpContext.Current.Session["GL_NACHBranchMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHBranchMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHBranchMaster
        {
            get
            {
                return GetNACHBranchMasterFromSession().GL_NACHBranchMaster;
            }
        }
        public static void SetNACHBranchMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHBranchMaster"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHUSERLOGFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHUSERLOG"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUSERLOG"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHUSERLOG
        {
            get
            {
                return GetNACHUSERLOGFromSession().GL_NACHUSERLOG;
            }
        }
        public static void SetNACHUSERLOGInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHUSERLOG"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHROLLOGFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHROLLOG"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHROLLOG"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHROLLOG
        {
            get
            {
                return GetNACHROLLOGFromSession().GL_NACHROLLOG;
            }
        }
        public static void SetNACHROLLOGInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHROLLOG"] = vUserObj;
        }
        //------------------
        public static UserObj GetAcceptFromSession()
        {
            if (HttpContext.Current.Session["GL_Accept"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Accept"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Accept
        {
            get
            {
                return GetAcceptFromSession().GL_Accept;
            }
        }
        public static void SetAcceptInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_Accept"] = vUserObj;
        }
        //---------------
        public static UserObj GetACKHistoryFromSession()
        {
            if (HttpContext.Current.Session["GL_ACKHistory"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ACKHistory"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_ACKHistory
        {
            get
            {
                return GetACKHistoryFromSession().GL_ACKHistory;
            }
        }
        public static void SetACKHistoryInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ACKHistory"] = vUserObj;
        }
     //------------------
        public static UserObj GetNACHMasterFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHMaster
        {
            get
            {
                return GetNACHMasterFromSession().GL_NACHMaster;
            }
        }
        public static void SetNACHMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHMaster"] = vUserObj;
        }
        //------------------
        // Modified by sobia on 14/01/2015 for Inward Batch
        public static UserObj GetNACHInwardBatchFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHInwardBatch"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHInwardBatch"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHInwardBatch
        {
            get
            {
                return GetNACHInwardBatchFromSession().GL_NACHInwardBatch;
            }
        }
        public static void SetNACHInwardBatchInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHInwardBatch"] = vUserObj;
        }
        //-----------------------------
        //----------------API------------------
        public static UserObj GetInwardAPIURLFromSession()
        {
            if (HttpContext.Current.Session["GL_InwardAPIURL"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_InwardAPIURL"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_InwardAPIURL
        {
            get
            {
                return GetInwardAPIURLFromSession().GL_InwardAPIURL;
            }
        }
        public static void SetInwardAPIURLInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_InwardAPIURL"] = vUserObj;
        }
        //------------------------------------------------

        public static UserObj GetNACHDestFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHDest"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHDest"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHDest
        {
            get
            {
                return GetNACHDestFromSession().GL_NACHDest;
            }
        }
        
        public static void SetNACHDestInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHDest"] = vUserObj;
        }
        //----------------------
        public static UserObj GetNACHTxnFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHTxn"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHTxn"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHTxn
        {
            get
            {
                return GetNACHTxnFromSession().GL_NACHTxn;
            }
        }
        public static void SetNACHTxnInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHTxn"] = vUserObj;
        }
        //------------------
        public static UserObj GetNACHUplaodMastFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHUplaodMast"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUplaodMast"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHUplaodMast
        {
            get
            {
                return GetNACHUplaodMastFromSession().GL_NACHUplaodMast;
            }
        }
        public static void SetNACHUplaodMastInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHUplaodMast"] = vUserObj;
        }
        //-------------------
        public static UserObj GetNACHDestInwFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHDestInw"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHDestInw"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHDestInw
        {
            get
            {
                return GetNACHDestInwFromSession().GL_NACHDestInw;
            }
        }
        public static void SetNACHDestInwInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHDestInw"] = vUserObj;
        }
       //--------------------
        public static UserObj GetNACHCrInwFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCrInw"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCrInw"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCrInw
        {
            get
            {
                return GetNACHCrInwFromSession().GL_NACHCrInw;
            }
        }
        public static void SetNACHCrInwInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCrInw"] = vUserObj;
        }
        //-------------------
        public static UserObj GetNACHDestInwHFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHDestInwH"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHDestInwH"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHDestInwH
        {
            get
            {
                return GetNACHDestInwHFromSession().GL_NACHDestInwH;
            }
        }
        public static void SetNACHDestInwHInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHDestInwH"] = vUserObj;
        }
        //------------------
        public static UserObj GetNACHBatchBalFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHBatchBal"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHBatchBal"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHBatchBal
        {
            get
            {
                return GetNACHBatchBalFromSession().GL_NACHBatchBal;
            }
        }
        public static void SetNACHBatchBalInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHBatchBal"] = vUserObj;
        }
        //-------------------
        public static UserObj GetNACHCycleMastFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCycleMast"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCycleMast"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCycleMast
        {
            get
            {
                return GetNACHCycleMastFromSession().GL_NACHCycleMast;
            }
        }
        public static void SetNACHCycleMastInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCycleMast"] = vUserObj;
        }
        //---------------------
        public static UserObj GetNACHClientPrDataTmpFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHClientPrDataTmp"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHClientPrDataTmp"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHClientPrDataTmp
        {
            get
            {
                return GetNACHClientPrDataTmpFromSession().GL_NACHClientPrDataTmp;
            }
        }
        public static void SetNACHClientPrDataTmpInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHClientPrDataTmp"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHClientTxnMastFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHClientTxnMast"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHClientTxnMast"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHClientTxnMast
        {
            get
            {
                return GetNACHClientTxnMastFromSession().GL_NACHClientTxnMast;
            }
        }
        public static void SetNACHClientTxnMastInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHClientTxnMast"] = vUserObj;
        }
        //-------------
        public static UserObj GetNACHCorporateMasterFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCorporateMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCorporateMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCorporateMaster
        {
            get
            {
                return GetNACHCorporateMasterFromSession().GL_NACHCorporateMaster;
            }
        }
        public static void SetNACHCorporateMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCorporateMaster"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHUtilityMasterFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHUtilityMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUtilityMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHUtilityMaster
        {
            get
            {
                return GetNACHUtilityMasterFromSession().GL_NACHUtilityMaster;
            }
        }
        public static void SetNACHUtilityMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHUtilityMaster"] = vUserObj;
        }
        //--------------------
        public static UserObj GetUSERMasterFromSession()
        {
            if (HttpContext.Current.Session["GL_USERMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_USERMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_USERMaster
        {
            get
            {
                return GetUSERMasterFromSession().GL_USERMaster;
            }
        }
        public static void SetUSERMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_USERMaster"] = vUserObj;
        }
        //=-----------------------
        public static UserObj GetSetUpFromSession()
        {
            if (HttpContext.Current.Session["GL_SETUP"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_SETUP"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_SETUP
        {
            get
            {
                return GetSetUpFromSession().GL_SETUP;
            }
        }
        public static void SetSetUPInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_SETUP"] = vUserObj;
        }
        
        //------------------------
        public static UserObj GetNACHSettlementMasterFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHSettlementMaster"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHSettlementMaster"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHSettlementMaster
        {
            get
            {
                return GetNACHSettlementMasterFromSession().GL_NACHSettlementMaster;
            }
        }
        public static void SetNACHSettlementMasterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHSettlementMaster"] = vUserObj;
        }
        //------------------
        public static UserObj GetNACHUploadTmpDataFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHUploadTmpData"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUploadTmpData"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHUploadTmpData
        {
            get
            {
                return GetNACHUploadTmpDataFromSession().GL_NACHUploadTmpData;
            }
        }
        public static void SetNACHUploadTmpDataInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHUploadTmpData"] = vUserObj;
        }
        //----------------
        public static UserObj GetUnlockFlagFromSession()
        {
            if (HttpContext.Current.Session["GL_UnlockFlag"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UnlockFlag"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static bool GL_UnlockFlag
        {
            get
            {
                return GetUnlockFlagFromSession().GL_UnlockFlag;
            }
        }
        public static void SetUnlockFlagInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UnlockFlag"] = vUserObj;
        }
        //----------------
        public static UserObj GetUploadFlagFromSession()
        {
            if (HttpContext.Current.Session["GL_UploadFlag"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_UploadFlag"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static bool GL_UploadFlag
        {
            get
            {
                return GetUploadFlagFromSession().GL_UploadFlag;
            }
        }
        public static void SetUploadFlagInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_UploadFlag"] = vUserObj;
        }
        //----------------
        public static UserObj GetNACHCmpnyCdFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCmpnyCd"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCmpnyCd"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCmpnyCd
        {
            get
            {
                return GetNACHCmpnyCdFromSession().GL_NACHCmpnyCd;
            }
        }
        public static void SetNACHCmpnyCdInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCmpnyCd"] = vUserObj;
        }
        //---------------------------
        public static UserObj GetNACHBankNameFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHBankName"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHBankName"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHBankName
        {
            get
            {
                return GetNACHBankNameFromSession().GL_NACHBankName;
            }
        }
        public static void SetNACHBankNameInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHBankName"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHSponsorCdFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHSponsorCd"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHSponsorCd"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHSponsorCd
        {
            get
            {
                return GetNACHSponsorCdFromSession().GL_NACHSponsorCd;
            }
        }
        public static void SetNACHSponsorCdInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHSponsorCd"] = vUserObj;
        }
        //--------------
        public static UserObj GetNPCIBankCdFromSession()
        {
            if (HttpContext.Current.Session["GL_NPCIBankCd"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NPCIBankCd"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NPCIBankCd
        {
            get
            {
                return GetNPCIBankCdFromSession().GL_NPCIBankCd;
            }
        }
        public static void SetNPCIBankCdInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NPCIBankCd"] = vUserObj;
        }
        //---------------
        public static UserObj GetNPCILoginIDFromSession()
        {
            if (HttpContext.Current.Session["GL_NPCILoginID"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NPCILoginID"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NPCILoginID
        {
            get
            {
                return GetNPCILoginIDFromSession().GL_NPCILoginID;
            }
        }
        public static void SetNPCILoginIDInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NPCILoginID"] = vUserObj;
        }
        //--------------------
        public static UserObj GetNACHScannerFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHScanner"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHScanner"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHScanner
        {
            get
            {
                return GetNACHScannerFromSession().GL_NACHScanner;
            }
        }
        public static void SetNACHScannerInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHScanner"] = vUserObj;
        }
        //-------------------
        public static UserObj GetNACHCheckerAuthFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCheckerAuth"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCheckerAuth"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCheckerAuth
        {
            get
            {
                return GetNACHCheckerAuthFromSession().GL_NACHCheckerAuth;
            }
        }
        public static void SetNACHCheckerAuthInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCheckerAuth"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHCheckerCorrectionFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCheckerCorrection"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCheckerCorrection"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHCheckerCorrection
        {
            get
            {
                return GetNACHCheckerCorrectionFromSession().GL_NACHCheckerCorrection;
            }
        }
        public static void SetNACHCheckerCorrectionInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCheckerCorrection"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHUploadAuthFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHUploadAuth"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHUploadAuth"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHUploadAuth
        {
            get
            {
                return GetNACHUploadAuthFromSession().GL_NACHUploadAuth;
            }
        }
        public static void SetNACHUploadAuthInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHUploadAuth"] = vUserObj;
        }
        //-----------------
        public static UserObj GetNACHMMSTimeFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHMMSTimeFrom"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHMMSTimeFrom"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHMMSTimeFrom
        {
            get
            {
                return GetNACHMMSTimeFromSession().GL_NACHMMSTimeFrom;
            }
        }
        public static void SetNACHMMSTimeFromInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHMMSTimeFrom"] = vUserObj;
        }
        //-------------------------
        public static UserObj SetNACHMMSTimeToFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHMMSTimeTo"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHMMSTimeTo"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHMMSTimeTo
        {
            get
            {
                return SetNACHMMSTimeToFromSession().GL_NACHMMSTimeTo;
            }
        }
        public static void SetNACHMMSTimeToInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHMMSTimeTo"] = vUserObj;
        }
        //--------------------
        public static UserObj GetNACHTRNTimeFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHTRNTimeFrom"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHTRNTimeFrom"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHTRNTimeFrom
        {
            get
            {
                return GetNACHTRNTimeFromSession().GL_NACHTRNTimeFrom;
            }
        }
        public static void SetNACHTRNTimeFromInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHTRNTimeFrom"] = vUserObj;
        }
        //-----------------------
        public static UserObj GetNACHTRNTimeToFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHTRNTimeTo"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHTRNTimeTo"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHTRNTimeTo
        {
            get
            {
                return GetNACHTRNTimeToFromSession().GL_NACHTRNTimeTo;
            }
        }
        public static void SetNACHTRNTimeToInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHTRNTimeTo"] = vUserObj;
        }
        //------------------
        public static UserObj GetOwnestOutwardFromSession()
        {
            if (HttpContext.Current.Session["GL_OwnestOutward"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_OwnestOutward"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_OwnestOutward
        {
            get
            {
                return GetOwnestOutwardFromSession().GL_OwnestOutward;
            }
        }
        public static void SetOwnestOutwardInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_OwnestOutward"] = vUserObj;
        }
        //------------------
        public static UserObj GetScanImagePathFromSession()
        {
            if (HttpContext.Current.Session["GL_ScanImagePath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ScanImagePath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_ScanImagePath
        {
            get
            {
                return GetScanImagePathFromSession().GL_ScanImagePath;
            }
        }

        // Modified by sobia on 14/01/2015 for inward batch size
        public static UserObj GetInwardBatchSizeFromSession()
        {
            if (HttpContext.Current.Session["GL_InwardBatchSize"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_InwardBatchSize"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_InwardBatchSize
        {
            get
            {
                return GetInwardBatchSizeFromSession().GL_InwardBatchSize;
            }
        }
        public static void SetInwardBatchSizeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_InwardBatchSize"] = vUserObj;
        }

        public static string GL_CBSURL
        {
            get
            {
                return GetInwardBatchSizeFromSession().GL_CBSURL;
            }
        }
        public static void SetCbsUrlInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_CBSURL"] = vUserObj;
        }
        public static void SetScanImagePathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ScanImagePath"] = vUserObj;
        }
        //--------------------
        public static UserObj GetMandateFormatFromSession()
        {
            if (HttpContext.Current.Session["GL_MandateFormat"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_MandateFormat"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_MandateFormat
        {
            get
            {
                return GetMandateFormatFromSession().GL_MandateFormat;
            }
        }
        public static void SetMandateFormatInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_MandateFormat"] = vUserObj;
        }
        //--------------------
        public static UserObj GetImagePathFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_ImagePath
        {
            get
            {
                return GetImagePathFromSession().GL_ImagePath;
            }
        }
        public static void SetImagePathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePath"] = vUserObj;
        }
        //------------------
        //public static UserObj GetImagePathOuterFromSession()
        //{
        //    if (HttpContext.Current.Session["GL_ImagePathOuter"] != null)
        //    {
        //        return (UserObj)HttpContext.Current.Session["GL_ImagePathOuter"];
        //    }
        //    else
        //    {
        //        UserObj utilityID = new UserObj();
        //        return utilityID;
        //    }
        //}
        //public static string GL_ImagePathOuter
        //{
        //    get
        //    {
        //        return GetImagePathOuterFromSession().GL_ImagePathOuter;
        //    }
        //}
        //public static void SetImagePathOuterInSession(UserObj vUserObj)
        //{
        //    HttpContext.Current.Session["GL_ImagePathOuter"] = vUserObj;
        //}

        //public static void SetImagePathOuterArchInSession(UserObj vUserObj)
        //{
        //    HttpContext.Current.Session["GL_ImagePathOuterArch"] = vUserObj;
        //}
        //-------------------

        //-------------------------------------------26122020
        #region for Archival_Image

        public static UserObj GetImagePathOuterFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePathOuter"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePathOuter"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }

        }
    
        public static void SetImagePathOuterInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePathOuter"] = vUserObj;
        }

        public static string GL_ImagePathOuter
        {
            get
            {
                return GetImagePathOuterFromSession().GL_ImagePathOuter;
            }
        }


       //================== GL Image Archival Outer 

      //  public string GL_ImagePathOuterArc { get; set; }

        public static string GL_ImagePathOuterArc
        {
            get
            {
                return GetImagePathOuterArcFromSession().GL_ImagePathOuterArc;
            }
        }

        public static void SetImagePathOuterArcInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePathOuterArc"] = vUserObj;
        }

        public static UserObj GetImagePathOuterArcFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePathOuterArc"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePathOuterArc"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }

        }

        //============================GL Image Outer Archival end

        //===========================GL Image Inward Archival start

        public static string GL_ImagePathInwardArc
        {
            get
            {
                return GetImagePathInwardArcFromSession().GL_ImagePathInwardArc;
            }
        }

        public static void SetImagePathInwardArcInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePathInwardArc"] = vUserObj;
        }

        public static UserObj GetImagePathInwardArcFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePathInwardArc"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePathInwardArc"];
            }
            else
            {
                UserObj uo = new UserObj();
                return uo;
            }

        }

        //==========================================================
       















        #endregion Archival_Image

        //-----------------------------------------------------------
        public static string GL_ImagePathTemp
        {
            get
            {
                return GetImagePathTempFromSession().GL_ImagePathTemp;
            }
        }

        public static void SetImagePathTempInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePathTemp"] = vUserObj;
        }

        public static UserObj GetImagePathTempFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePathTemp"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePathTemp"];
            }
            else
            {
                UserObj Uobj = new UserObj();
                return Uobj;
            }

        }

        //-----------------------------------------------------
        public static UserObj GetImagePathShowFromSession()
        {
            if (HttpContext.Current.Session["GL_ImagePathShow"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_ImagePathShow"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_ImagePathShow
        {
            get
            {
                return GetImagePathShowFromSession().GL_ImagePathShow;
            }
        }
        public static void SetImagePathShowInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_ImagePathShow"] = vUserObj;
        }
        //-----------------
        public static UserObj GetInwardImagePathFromSession()
        {
            if (HttpContext.Current.Session["GL_InwardImagePath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_InwardImagePath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_InwardImagePath
        {
            get
            {
                return GetInwardImagePathFromSession().GL_InwardImagePath;
            }
        }
        public static void SetInwardImagePathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_InwardImagePath"] = vUserObj;
        }
        //----------------

        public static UserObj GetDownloadpathFromSession()
        {
            if (HttpContext.Current.Session["GL_Downloadpath"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Downloadpath"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Downloadpath
        {
            get
            {
                return GetDownloadpathFromSession().GL_Downloadpath;
            }
        }
        public static void SetDownloadpathInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_Downloadpath"] = vUserObj;
        }
        //---------------
       
        public static UserObj GetMinDateFromSession()
        {
            if (HttpContext.Current.Session["GL_MinDate"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_MinDate"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_MinDate
        {
            get
            {
                return GetMinDateFromSession().GL_MinDate;
            }
        }
              
        public static UserObj GetOwnerFromSession()
        {
            if (HttpContext.Current.Session["GL_Owner"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_Owner"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_Owner
        {
            get
            {
                return GetOwnerFromSession().GL_Owner;
            }
        }

        //----------------------------------------------
        public static UserObj GetBankCodeFromSession()
        {
            if (HttpContext.Current.Session["GL_BankCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_BankCode"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_BankCode
        {
            get
            {
                return GetBankCodeFromSession().GL_BankCode;
            }
        }
        public static void SetBankCodeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_BankCode"] = vUserObj;
        }

        public static UserObj GetNACHTxnInwardCbsResFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHTxnInwardCbsRes"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHTxnInwardCbsRes"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_NACHTxnInwardCbsRes
        {
            get
            {
                return GetSetUpFromSession().GL_NACHTxnInwardCbsRes;
            }
        }
        public static void SetNACHTxnInwardCbsResInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHTxnInwardCbsRes"] = vUserObj;
        }

        public static string GL_NACHCategory
        {
            get
            {
                return GetNACHCategoryFromSession().GL_NACHCategory;
            }
        }
        
        public static UserObj GetNACHCategoryFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCategory"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCategory"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }

        public static string GL_NACHSolId
        {
            get
            {
                return GetNACHSolIdFromSession().GL_NACHSolId;
            }
        }

        public static UserObj GetNACHSolIdFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHSolId"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHSolId"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }

        public static void SetNACHSolIdInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHSolId"] = vUserObj;
        }

        public static string GL_NACHCircleCode
        {
            get
            {
                return GetNACHCircleCodeFromSession().GL_NACHCircleCode;
            }
        }

        public static UserObj GetNACHCircleCodeFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHCircleCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHCircleCode"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }

        public static string GL_NACHZoneCode
        {
            get
            {
                return GetNACHZoneCodeFromSession().GL_NACHZoneCode;
            }
        }

        public static UserObj GetNACHZoneCodeFromSession()
        {
            if (HttpContext.Current.Session["GL_NACHZoneCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_NACHZoneCode"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }

        public static void SetNACHCategoryInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCategory"] = vUserObj;
        }

        public static void SetNACHBranchNameInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHBranchName"] = vUserObj;
        }

        public static void SetNACHZoneCodeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHZoneCode"] = vUserObj;
        }

        public static void SetNACHCircleCodeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_NACHCircleCode"] = vUserObj;
        }

        public static UserObj GetCBOCodeFromSession()
        {
            if (HttpContext.Current.Session["GL_CBOCode"] != null)
            {
                return (UserObj)HttpContext.Current.Session["GL_CBOCode"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
        public static string GL_CBOCode
        {
            get
            {
                return GetCBOCodeFromSession().GL_CBOCode;
            }
        }
        public static void SetCBOCodeInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["GL_CBOCode"] = vUserObj;
        }

        //17/02/2018
        public static string GL_NPCI_H2HLOGINID
        {
            get
            {
                return GetNPCIH2HLoginIDFromSession().GL_NPCI_H2HLOGINID;
            }
        }

        //17/02/2018
        public static void SetNPCIH2HLoginIDInSession(UserObj vUserObj)
        {
            HttpContext.Current.Session["NPCI_H2HLOGINID"] = vUserObj;
        }

        //17/02/2018
        public static UserObj GetNPCIH2HLoginIDFromSession()
        {
            if (HttpContext.Current.Session["NPCI_H2HLOGINID"] != null)
            {
                return (UserObj)HttpContext.Current.Session["NPCI_H2HLOGINID"];
            }
            else
            {
                UserObj utilityID = new UserObj();
                return utilityID;
            }
        }
    }
}
