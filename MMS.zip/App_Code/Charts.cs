using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Web.UI.DataVisualization.Charting;
using System.Drawing;


public class MyCharts
{
    private Chart ChartObj { get; set; }
    private Label LabelGraph { get; set; }
    private Label LabelHead { get; set; }
    private DropDownList DropDownObj { get; set; } 
    private Font FontLabelGraph { get; set; }
    private Font FontTitleGraph { get; set; }
    private Font FontAxisObj { get; set; }

    //Order of Colors Blue, Red, Green, etc.
    Color[] Colors_Old = {  Color.FromArgb(78,135,205), Color.FromArgb(201,62,58),
                            Color.FromArgb(125,158,56), Color.FromArgb(96,68,130),
                            Color.FromArgb(39,130,155), Color.FromArgb(218,117,33),
                            Color.FromArgb(39,64,139), Color.FromArgb(0,128,128),
                            Color.FromArgb(0,104,139), Color.FromArgb(126,126,126)};

    Color[] BGColors = { Color.FromArgb(247, 248, 250) };

    Color[] Colors = { Color.FromArgb(255,153,0), Color.FromArgb(204,255,255),
                       Color.FromArgb(120,120,250), Color.FromArgb(255,255,0),
                       Color.FromArgb(255,0,0)};

    public MyCharts(Chart vChart, Label vLabelGraph, Label vLabelHead, DropDownList vDropDown)
    {
        this.ChartObj = vChart;
        this.LabelGraph = vLabelGraph;
        this.LabelHead = vLabelHead;
        this.DropDownObj = vDropDown;

        this.FontLabelGraph = new Font("verdana", 9, FontStyle.Bold);
        this.FontAxisObj = new Font("verdana", 9, FontStyle.Regular);
        this.FontTitleGraph = new Font("verdana", 9, FontStyle.Regular);
    }

    public MyCharts(Chart vChart, Label vLabelHead)
    {
        this.ChartObj = vChart;
        this.LabelHead = vLabelHead;

        this.FontLabelGraph = new Font("verdana", 9, FontStyle.Bold);
        this.FontAxisObj = new Font("verdana", 9, FontStyle.Regular);
        this.FontTitleGraph = new Font("verdana", 9, FontStyle.Regular);
    }

    public void DrawBarChart(DataSet vDSet)
    {
        DataTable mDTable = null;
        String mTotalWF = String.Empty;

        Title mTitle = new Title();
        Series mSeries = new Series();

        ChartArea mChartArea = new ChartArea();
        CustomLabel mCustomLabel = new CustomLabel();
        DataPoint mPoint = null;
        Axis mAxis = null;

        int mXAxisCstLoop = 1;
        int mSeriesLoop = 0;

        try
        {
            mDTable = vDSet.Tables[0];
            DataView mDView = new DataView(vDSet.Tables[0]);

            mTotalWF = vDSet.Tables[2].Rows[0]["ColNames"].ToString();

            this.LabelHead.Text = vDSet.Tables[1].Rows[0]["HeadName"].ToString();

            //Add Series
            foreach (String mText in mTotalWF.Split(','))
            {
                double mLoop = 1.0;
                String mLabelVal = String.Empty;

                mSeries.ChartType = SeriesChartType.Column;
                mSeries.CustomProperties = "PointWidth=0.7";
                mSeries.BorderWidth = 2;
                mSeries.ShadowOffset = 3;

                mSeries.ShadowColor = Color.Silver;
                mSeries.Name = mText;
                mSeries.LabelForeColor = Color.Black;

                foreach (DataRow mDRow in mDTable.Rows)
                {
                    mLabelVal = mDRow[mText].ToString();

                    mPoint = new DataPoint();
                    mPoint.XValue = mLoop;
                    mPoint.SetValueXY(mLoop, mLabelVal);

                    if ((mLabelVal != "0") && (mLabelVal != "0.0"))
                    {
                        mPoint.IsValueShownAsLabel = true;
                    }
                    else
                    {
                        mPoint.IsValueShownAsLabel = false;
                    }
                    mSeries.Points.Add(mPoint);
                    mLoop++;
                }

                if (mSeriesLoop >= this.Colors.Length)
                    mSeriesLoop = 0;

                mSeries.Points[0].Color = this.Colors[0];
                mSeries.Points[1].Color = this.Colors[1];
                mSeries.Points[2].Color = this.Colors[2];
                mSeries.Points[3].Color = this.Colors[3];
                mSeries.Points[4].Color = this.Colors[4];

                mSeries.Font = this.FontLabelGraph;

                this.ChartObj.Series.Add(mSeries);

                mSeriesLoop++;
            }

            //Add Y-Axis
            Int32 YAxisMaxVal = Convert.ToInt32(vDSet.Tables[1].Rows[0]["YAxisMaxVal"].ToString());

            Int32 Step = Convert.ToInt32(vDSet.Tables[1].Rows[0]["Step"].ToString());

            mChartArea.AxisY.MajorGrid.LineColor = Color.White;
            mChartArea.AxisY.Maximum = Convert.ToDouble(YAxisMaxVal);
            mChartArea.AxisY.Interval = Convert.ToDouble(Step);
            mChartArea.AxisY.LabelStyle.Font = this.FontAxisObj;

            //Add X-Axis
            mChartArea.AxisX.MajorGrid.LineColor = Color.White;
            mChartArea.AxisX.Maximum = mDTable.Rows.Count + 1;
            mChartArea.AxisX.Interval = 1;

            mChartArea.AxisX.MajorTickMark.Interval = 1.0;
            mChartArea.AxisX.IsMarginVisible = true;
            mChartArea.AxisX.LabelStyle.Font = this.FontAxisObj;
            mChartArea.AxisX.IsLabelAutoFit = true;
            mChartArea.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.LabelsAngleStep90;

            //Custom label for X-Axis
            foreach (DataRow mDRow in mDTable.Rows)
            {
                mCustomLabel = new CustomLabel();
                mCustomLabel.FromPosition = double.Parse((mXAxisCstLoop - 0.5).ToString());
                mCustomLabel.ToPosition = double.Parse((mXAxisCstLoop + 0.5).ToString());

                mCustomLabel.Text = mDRow["DataLabel"].ToString();
                mChartArea.AxisX.CustomLabels.Add(mCustomLabel);
                mXAxisCstLoop++;
            }

            mAxis = mChartArea.AxisX;
            //##Aadil             
            mAxis.Title = "Open tickets & tickets pending for action";
            mAxis.TitleFont = this.FontTitleGraph;

            mAxis.TitleForeColor = Color.Black;

            this.ChartObj.Font.Name = "arial";
            this.ChartObj.Font.Size = new FontUnit(11);
            this.ChartObj.ChartAreas.Add(mChartArea);
            this.ChartObj.Height = Unit.Pixel(300);
            this.ChartObj.Width = Unit.Pixel(650);
        }
        catch (Exception ex)
        {            
            throw ex;
        }
    }
}
