﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserSession
/// </summary>
/// 
[Serializable]
public class UserObj
{
    public UserObj()
    {
        GL_MinDate = "01/01/1900";
        GL_Owner = "ECS";
    }
    //
    // TODO: Add constructor logic here
    //
    public string UserCode { get; set; }
    public string UserName { get; set; } 
    public string BranchName { get; set; }
    public string BranchID { get; set; }
    public string SoleID { get; set; }

    //public string UtilityId { get; set; }
    public string GL_NACHUtilityID { get; set; }
    public string GL_NACHUtilityCd { get; set; }
    public string GL_NACHUtilityName { get; set; }
    public string GL_NACHEcsAccNo { get; set; }
    public string GL_NPCIUserNo { get; set; }
    public string GL_NPCIUserName { get; set; }
    public string GL_NPCIUserCode { get; set; }

    public string GL_NACHResetPWD { get; set; }

    public string GL_ProductCode { get; set; }
    public string GL_MaxAmount { get; set; }
    public string GL_Product { get; set; }

    //---------------09/07/2014----------------
    public string GL_MandateData  { get; set; }
    public string GL_Inward  { get; set; }
    public string GL_Outward { get; set; }
    public string GL_ClientMaster { get; set; }
    public string GL_Batch { get; set; }
    public string GL_Accept { get; set; }
    public string GL_ACKHistory { get; set; }
    public string GL_NACHClientD { get; set; }
    public string GL_NACHMaster { get; set; }
    public string GL_NACHCycleMast { get; set; }
    public string GL_NACHClientPrData { get; set; }
    public string GL_NACHClientPrDataTmp { get; set; }
    public string GL_NACHClientTxnMast { get; set; }
    public string GL_NACHUploadTmpData { get; set; }

    public string GL_NACHDest { get; set; }
    public string GL_NACHInwardBatch { get; set; }   // Modified by sobia on 14/01/2015 for Inward Batch
    public string GL_NACHTxn { get; set; }
    public string GL_NACHUplaodMast { get; set; }
    public string GL_NACHDestInw { get; set; }
    public string GL_NACHCrInw { get; set; }
    public string GL_NACHDestInwH { get; set; }
    public string GL_NACHTXNClientHeader { get; set; }
    public string GL_NACHTXNClientData { get; set; }
    public string GL_NACHCorporateMaster { get; set; }
    public string GL_NACHUtilityMaster { get; set; }
    public string GL_USERMaster { get; set; }
    public string GL_SETUP { get; set; }
    public string GL_NACHSettlementMaster { get; set; }
    public string GL_NACHBranchMaster { get; set; }

    public string GL_UserName { get; set; }  // For session timeout 
    public string GL_UserCode { get; set; }  // For session timeout 
    public string GL_UserPwd { get; set; }
    public string GL_NACHCmpnyCd { get; set; }
    public string GL_NACHBankName { get; set; }
    public string GL_NPCIBankCd { get; set; }
    public string GL_NPCILoginID { get; set; }
    public string GL_NACHSponsorCd { get; set; }  
    public string GL_NACHScanner { get; set; }
    public string GL_NACHCheckerAuth { get; set; }
    public string GL_NACHCheckerCorrection { get; set; }
    public string GL_NACHUploadAuth { get; set; }
    public string GL_NACHMMSTimeFrom { get; set; }
    public string GL_NACHMMSTimeTo { get; set; }
    public string GL_NACHTRNTimeFrom { get; set; }
    public string GL_NACHTRNTimeTo { get; set; }

    public string GL_ImagePathShow { get; set; }
    public string GL_NACHUSERLOG { get; set; }
    public string GL_NACHROLLOG { get; set; }
    public string GL_ImagePath { get; set; }
   

    //---------------------
    public string GL_ImagePathOuter { get; set; }

    public string GL_ImagePathOuterArc { get; set; }   //26122020

    public string GL_ImagePathInwardArc { get; set; }   //26122020

    //----------------

    public string GL_ImagePathTemp { get; set; }

    public string GL_DashBoardName { get; set; }
    public string GL_OwnestOutward { get; set; }
    //Global variable for Path and SystemDate

    public string GL_SystmDt { get; set; }
    public string GL_ReportPath { get; set; }
    public string GL_UploadPath { get; set; }
    public string GL_InwardImagePath { get; set; }
    public string GL_ScanImagePath { get; set; }
    //Modified by sobia on 14/01/2015 for inward batch size
    public string GL_InwardBatchSize { get; set; }
    public string GL_MandateFormat { get; set; }
    public string GL_NACHBatchBal { get; set; }
    public Boolean GL_UploadFlag = false;
    public bool GL_UnlockFlag = false;
    public string GL_InwardAPIURL { get; set; }
    public string GL_CBSURL { get; set; }
    //Global variable for for skiping signout updates in company master
    public bool GL_CompanySelected = false;

    //------For downloading -------
    public string GL_Downloadpath { get; set; }

    public string GL_MinDate { get; set; }

    public string GL_Owner { get; set; }

    public string GL_BankCode { get; set; }

    public string GL_NACHTxnInwardCbsRes { get; set; }

    public string GL_NACHCategory { get; set; }
    public string GL_NACHSolId { get; set; }
    public string GL_NACHCircleCode { get; set; }
    public string GL_NACHZoneCode { get; set; }
    public string GL_NACHBranchName { get; set; }

    public string GL_CBOCode { get; set; } //23/01/2018

    //17/02/2018
    public string GL_NPCI_H2HLOGINID { get; set; }

   // public string GL_ImagePathTemp { get; set; }
}