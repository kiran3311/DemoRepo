﻿using Impersonator;
using NACH_Application;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options_DownloadFiles : System.Web.UI.Page
{
    string settlementDate;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                txtSettltmentDt.Text = DateTime.Now.ToString("dd/MM/yyyy");
            }
            else 
            {
                //   Response.Redirect(Request.RawUrl);
            }
            settlementDate = txtSettltmentDt.Text.Replace("-", "");
        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    protected void ddlModule_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void dgvData_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        btnOk_Click(null, null);
        dgvData.PageIndex = e.NewPageIndex;
        dgvData.DataBind();
    }

    protected void cvOk_ServerValidate(object source, ServerValidateEventArgs args)
    {
    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlModule.SelectedItem.Text == "<--Select-->")
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please select the Module');", true);
                return;
            }
            if (ddlModule.SelectedValue == "Register_Mandate")
            {
                string strPath = "/Data/" + cls_General.GL_CmpnyCd + "/RegisterMandate/" + settlementDate + "/";
                if (Directory.Exists(cls_General.GL_ReportPath + "\\RegisterMandate\\" + settlementDate))
                {
                    string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + strPath));
                    List<ListItem> files = new List<ListItem>();
                    foreach (string filePath in filePaths)
                    {
                        files.Add(new ListItem(Path.GetFileName(filePath), filePath));
                    }
                    dgvData.DataSource = files;
                    dgvData.DataBind();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No data found');", true);
                    return;
                }
            }
            if (ddlModule.SelectedValue == "Approve_Mandate")
            {
                string strPath = "/Data/" + cls_General.GL_CmpnyCd + "/ApproveMandate/" + settlementDate + "/";
                if (Directory.Exists(cls_General.GL_ReportPath + "\\ApproveMandate\\" + settlementDate))
                {
                    string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + strPath));
                    List<ListItem> files = new List<ListItem>();
                    foreach (string filePath in filePaths)
                    {
                        files.Add(new ListItem(Path.GetFileName(filePath), filePath));
                    }
                    dgvData.DataSource = files;
                    dgvData.DataBind();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No data found');", true);
                    return;
                }
            }
            //if (ddlModule.SelectedItem.Text == "Request Payment")
            //{
            //    string strPath = "/Data/" + cls_General.GL_CmpnyCd + "/RequestPayment/" + DateTime.Now.ToString("ddMMyyyy") + "/";
            //    if (Directory.Exists(cls_General.GL_ReportPath + "\\RequestPayment\\" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy")))
            //    {
            //        string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + strPath));
            //        List<ListItem> files = new List<ListItem>();
            //        foreach (string filePath in filePaths)
            //        {
            //            files.Add(new ListItem(Path.GetFileName(filePath), filePath));
            //        }
            //        dgvData.DataSource = files;
            //        dgvData.DataBind();
            //    }
            //}
            //if (ddlModule.SelectedItem.Text == "Approve Payment")
            //{
            //    string strPath = "/Data/" + cls_General.GL_CmpnyCd + "/ApprovePayment//" + DateTime.Now.ToString("ddMMyyyy") + "/";
            //    if (Directory.Exists(cls_General.GL_ReportPath + "\\ApprovePayment\\" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy")))                   
            //    {
            //        string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + strPath));
            //        List<ListItem> files = new List<ListItem>();
            //        foreach (string filePath in filePaths)
            //        {
            //            files.Add(new ListItem(Path.GetFileName(filePath), filePath));
            //        }
            //        dgvData.DataSource = files;
            //        dgvData.DataBind();
            //    }
            //}
            //if (ddlModule.SelectedItem.Text == "CECS File")
            //{
            //    string strPath = "/Data/" + cls_General.GL_CmpnyCd + "/ECSconversion//" + DateTime.Now.ToString("ddMMyyyy") + "/";
            //    if (Directory.Exists(cls_General.GL_ReportPath + "\\ECSconversion\\" + Convert.ToDateTime(cls_General.GL_SystmDt).ToString("ddMMyyyy")))
            //    {
            //        string[] filePaths = Directory.GetFiles(Server.MapPath("~/" + strPath));
            //        List<ListItem> files = new List<ListItem>();
            //        foreach (string filePath in filePaths)
            //        {
            //            files.Add(new ListItem(Path.GetFileName(filePath), filePath));
            //        }
            //        dgvData.DataSource = files;
            //        dgvData.DataBind();
            //    }
            //}
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    protected void lnkBtnDetails_Click(object sender, EventArgs e)
    {
        try
        {
            string strFileName = (sender as LinkButton).CommandArgument;
            Response.Redirect("DownloadFilesTemp.aspx?FileName=" + strFileName + "&Module=" + ddlModule.SelectedItem.Text + "&SettlementDate=" + settlementDate);
        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    protected void lnkBtnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            hiddFileName.Value = (sender as LinkButton).CommandArgument;
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "message", "DeleteConfirmation();", true);
        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    protected void hiddDelete_Click(object sender, EventArgs e)
    {
        try
        {
            string strFilePath = string.Empty;
            if (ddlModule.SelectedValue == "Register_Mandate")
            {
                if (File.Exists(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/RegisterMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value)))
                {
                    File.Delete(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/RegisterMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value));
                }

            }
            else if (ddlModule.SelectedValue == "Approve_Mandate")
            {
                if (File.Exists(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/ApproveMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value)))
                {
                    File.Delete(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/ApproveMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value));
                }

            }
            //else if (ddlModule.SelectedItem.Text == "Request Payment")
            //{
            //    if (File.Exists(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/RequestPayment/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value)))
            //    {
            //        File.Delete(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/RequestPayment/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value));
            //    }

            //}
            //else if (ddlModule.SelectedItem.Text == "Approve Payment")
            //{
            //    if (File.Exists(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/ApprovePayment/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value)))
            //    {
            //        File.Delete(Server.MapPath("~/Data/" + cls_General.GL_CmpnyCd + "/ApprovePayment/" + DateTime.Now.ToString("ddMMyyyy") + "/") + System.IO.Path.GetFileName(hiddFileName.Value));
            //    }

            //}
            btnOk_Click(null, null);

        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }

    protected void lnkBtnSend_Click(object sender, EventArgs e)
    {
        try
        {
            var impersonate = new WrappedImpersonationContext(System.Configuration.ConfigurationManager.AppSettings["Domain"].ToString(), System.Configuration.ConfigurationManager.AppSettings["UserID"].ToString(), System.Configuration.ConfigurationManager.AppSettings["Pass"].ToString());//System.Configuration.ConfigurationManager.AppSettings["UserID"].ToString(), System.Configuration.ConfigurationManager.AppSettings["Pass"].ToString());
            impersonate.Enter();

            string strFileName = (sender as LinkButton).CommandArgument;
            //if (File.Exists(strFileName))
            //{
            //  
            // Response.Redirect("DownloadFilesTemp.aspx?FileName=" + strFileName + "&Module=" + ddlModule.SelectedItem.Text);

            string strFilePath = String.Empty;
            //string H2Hupload = System.Configuration.ConfigurationManager.AppSettings["H2HUpload"].ToString();
            string H2Hupload = System.Configuration.ConfigurationManager.AppSettings["H2H_NPCI_RTNFile"].ToString();

            if (ddlModule.SelectedItem.Text == "Register Mandate")
            {
                strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/RegisterMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/" + strFileName;
                string s = System.Web.HttpContext.Current.Server.MapPath(strFilePath);
                //System.IO.File.Copy(s, H2Hupload + strFileName);
                
                if (File.Exists(H2Hupload + strFileName))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('File Already Sent');", true);
                }
                else
                {
                    System.IO.File.Copy(s, H2Hupload + strFileName);
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('File sent Successfully..!');", true);
                    return;
                }
            }
            else if (ddlModule.SelectedItem.Text == "Approve Mandate")
            {
                strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/ApproveMandate/" + DateTime.Now.ToString("ddMMyyyy") + "/" + strFileName;
                string s = System.Web.HttpContext.Current.Server.MapPath(strFilePath);
                
                if (File.Exists(H2Hupload + strFileName))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('File Already Sent');", true);
                }
                else
                {                    
                    System.IO.File.Copy(s, H2Hupload + strFileName, true);
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('File sent Successfully..!');", true);
                    return;
                }
                
                //try
                //{
                //    System.IO.File.Copy(s, H2Hupload + strFileName, true);
                //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('File send Sucessfully..!');", true);
                //    return;
                //}
                //catch (Exception ex)
                //{
                //    Console.WriteLine(ex.StackTrace);
                //    throw ex;
                //}
            }
            else if (ddlModule.SelectedItem.Text == "ACH Debit Outward")
            {
                strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/RequestPayment/" + DateTime.Now.ToString("ddMMyyyy") + "/" + strFileName;
                string s = System.Web.HttpContext.Current.Server.MapPath(strFilePath);

                if (File.Exists(H2Hupload + strFileName))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('File Already Sent');", true);
                }
                else
                {
                    //System.IO.File.Copy(s, H2Hupload + strFileName);
                    System.IO.File.Copy(s, H2Hupload + strFileName);
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('File sent Successfully..!');", true);
                    return;
                }
            }
            else if (ddlModule.SelectedItem.Text == "ACH Debit Inward")
            {
                strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/ApprovePayment/" + DateTime.Now.ToString("ddMMyyyy") + "/" + strFileName;
                string s = System.Web.HttpContext.Current.Server.MapPath(strFilePath);

                if (File.Exists(H2Hupload + strFileName))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Error", "alert('File Already Sent');", true);
                }
                else
                {
                    //System.IO.File.Copy(s, H2Hupload + strFileName);
                    System.IO.File.Copy(s, H2Hupload + strFileName);
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('File send Successfully..!');", true);
                    return;
                }

                //System.IO.File.Copy(s, H2Hupload + strFileName);
                //  File.SetAttributes(H2Hupload + strFileName, FileAttributes.Normal);
            }
            else if (ddlModule.SelectedItem.Text == "ACH-CR File")
            {
                //strFilePath = "~/Data/ACH/" + DateTime.Now.ToString("ddMMyyyy") + "/" + cls_General.GL_Downloadpath;
                strFilePath = "~/Data/5/ACH CR Outward/" + DateTime.Now.ToString("ddMMyyyy") + "/" + cls_General.GL_Downloadpath;
                string s = System.Web.HttpContext.Current.Server.MapPath(strFilePath);
                System.IO.File.Copy(s, H2Hupload + strFileName);
            }
            //}
            //else
            //{
            //    Response.Redirect(Request.RawUrl);  
            //}
            //string filePath = (sender as LinkButton).CommandArgument;
            //cls_General.GL_Downloadpath = filePath;
            //string strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/" + DateTime.Now.ToString("ddMMyyyy") + "/" + cls_General.GL_Downloadpath;
            //Response.ClearContent();
            //Response.ContentType = "text/plain";
            //Response.AddHeader("Content-Disposition", "attachment;filename=" + cls_General.GL_Downloadpath + ";");
            //// Response.TransmitFile(System.Web.HttpContext.Current.Server.MapPath(strFilePath));   // TransmitFile &  WriteFile works same way       
            //Response.WriteFile(Server.MapPath(strFilePath));            
            //Response.Flush();
            //System.IO.File.Delete(Server.MapPath(strFilePath));
            //Response.End();
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
}