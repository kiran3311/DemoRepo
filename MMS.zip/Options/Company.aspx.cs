﻿using NACH.BLL;
using NACH.StateClass;
using NACH_Application;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options_Company : System.Web.UI.Page
{

    public CompanySC Doc { get; set; }

    cls_General m_cls = new cls_General();
    cls_DBConnection DbObj = new cls_DBConnection(); 
    string m_str;
    SqlDataReader dr;
    UserObj mUserObj = new UserObj();
    string provider = "RSAProtectedConfigurationProvider";

    string section = "connectionStrings";
    protected void Page_Load(object sender, EventArgs e)
    {
        string username = cls_General.GL_UsrNm; //23/01/2018
        CompanyBLL objCompanyBll = new CompanyBLL();
        try
        {
            InitDoc();
            if (cls_General.GL_NACHResetPWD == "1")
            {
                Response.Redirect("~/Master/ChangePassword.aspx", false);
            }
            else
            {
                if (!Page.IsPostBack)
                {
                    //if (cls_General.GL_NACHResetPWD == "1")
                    //{
                    //    Response.Redirect("~/Master/ChangePassword.aspx", false);
                    //}
                    //else
                    //{
                    //LinkButton lnkBtnLogout = (LinkButton)Master.FindControl("lnkBtnLogout");
                    //lnkBtnLogout.Visible = true;
                    //LinkButton lnkbtnHome = (LinkButton)Master.FindControl("lnkHome");
                    //lnkbtnHome.Visible = false;
                    Menu myMenu = (Menu)Master.FindControl("NavigationMenu");
                    myMenu.Visible = false;
                    if (!Page.IsPostBack)
                    {
                        txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                        txtDate.Enabled = false;
                        this.Doc.RecType = "Client";
                        DataSet mDataSet = new DataSet();
                        CompanyBLL mCompanyBLL = new CompanyBLL();
                        mDataSet = mCompanyBLL.GetData(this.Doc);
                        if (mDataSet != null && mDataSet.Tables[0].Rows.Count > 0)
                        {
                            ddlClient.Items.Insert(0, "<--Select-->");
                            ddlClient.DataSource = mDataSet.Tables[0];
                            //ddlClient.DataTextField = "name1";
                            ddlClient.DataTextField = "NAME";
                            ddlClient.DataValueField = "CO_CODE";
                            ddlClient.DataBind();
                            ddlClient.Focus();
                            ddlClient.SelectedIndex = 1;
                            ddlClient_SelectedIndexChanged(null, null);
                        }
                    }
                    //}
                }
            }
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
    private void InitDoc()
    {
        this.Doc = new CompanySC();
    }
    protected void btnEncrypt_Click(object sender, EventArgs e)
    {
        Configuration confg = null;
        confg = WebConfigurationManager.OpenWebConfiguration("~");

        ConfigurationSection configSect = confg.GetSection(section);

        if (!configSect.SectionInformation.IsProtected)
        {
            //this line will encrypt the file
            configSect.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
        }
        configSect.SectionInformation.ForceSave = true;
        // Save the current configuration
        confg.Save();
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {

        DateTime outDate;
        SessionOut SOut = (SessionOut)Session["SessionOutObj"];
        try
        {
            if (ddlClient.Text == "<--Select-->")
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Select the Company');", true);
                ddlClient.Focus();
                return;
            }
            if (ddlUtility.Text == "<--Select-->")
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Select the Utility');", true);
                ddlUtility.Focus();
                return;
            }

            mUserObj.GL_CompanySelected = true;
            cls_General.SetCompanySelectedInSession(mUserObj);
            string m_sysDate = txtDate.Text;

            mUserObj.GL_SystmDt = m_sysDate;
            cls_General.SetSystmDtInSession(mUserObj);
            //---------for Company--------

            CompanyObj mCompanyObj;
            mCompanyObj = new CompanyObj();
            mCompanyObj.CompanyName = ddlClient.SelectedItem.ToString().Trim();
            mCompanyObj.CompanyCode = ddlClient.SelectedValue.ToString().Trim();

            cls_General.SetCompanyObjInSession(mCompanyObj);

            mUserObj.GL_ReportPath = Server.MapPath("~\\Data\\" + cls_General.GL_CmpnyCd) + "\\";
            cls_General.SetReportPathInSession(mUserObj);

            if (Directory.Exists(mUserObj.GL_ReportPath) == false)
            {
                Directory.CreateDirectory(mUserObj.GL_ReportPath);
            }
            if (Directory.Exists(mUserObj.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy")) == false)
            {
                Directory.CreateDirectory(mUserObj.GL_ReportPath + DateTime.Now.ToString("ddMMyyyy"));
            }

            mUserObj.GL_Batch = "NACHBATCH_" + cls_General.GL_CmpnyCd;
            cls_General.SetBatchInSession(mUserObj);
            mUserObj.GL_MandateData = "NACHOUTWARD_" + cls_General.GL_CmpnyCd;                      //New Mandate
            cls_General.SetMandateDataInSession(mUserObj);
            mUserObj.GL_Inward = "NACH_INWARD";
            cls_General.SetInwardInSession(mUserObj);//Inward Details
            mUserObj.GL_Outward = "NACH_OUTWARD";
            cls_General.SetOutwardInSession(mUserObj);//Outward Details
            mUserObj.GL_NACHBranchMaster = "NACH_BRANCHMASTER";
            cls_General.SetNACHBranchMasterInSession(mUserObj);
            //----------sumedh-----
            TableObj mTableObj;                                                                //' Flag (Error Code) Master
            mTableObj = new TableObj();
            mTableObj.FLAGMASTER = "NACH_FLAGMASTER";
            cls_General.SetTableObjInSession(mTableObj);
            //-----------For user log------

            mUserObj.GL_NACHUSERLOG = "NACH_USERLOGMASTER";
            cls_General.SetNACHUSERLOGInSession(mUserObj);
            mUserObj.GL_NACHROLLOG = "NACH_ROLELOGMASTER";
            cls_General.SetNACHROLLOGInSession(mUserObj);

            mUserObj.GL_Accept = "MANDATE_ACCEPT";
            cls_General.SetAcceptInSession(mUserObj);
            mUserObj.GL_ACKHistory = "NACHMANDREJHISTORY_" + cls_General.GL_CmpnyCd;
            cls_General.SetACKHistoryInSession(mUserObj);

            mUserObj.GL_NACHMaster = "NACHMASTER_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHMasterInSession(mUserObj);
            mUserObj.GL_NACHDest = "NACHINWARD_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHDestInSession(mUserObj);
            mUserObj.GL_NACHTxn = "NACHTXNOUTWARD_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHTxnInSession(mUserObj);
            mUserObj.GL_NACHUplaodMast = "NACH_UPLOADMASTER";
            cls_General.SetNACHUplaodMastInSession(mUserObj);
            mUserObj.GL_NACHDestInw = "NACHTXNINWARD_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHDestInwInSession(mUserObj);
            mUserObj.GL_NACHCrInw = "NACHINWARDCREDIT_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHCrInwInSession(mUserObj);
            mUserObj.GL_NACHDestInwH = "NACHTXNINWARDHEADER_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHDestInwHInSession(mUserObj);
            mUserObj.GL_NACHBatchBal = "NACHCLIENTBATCH_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHBatchBalInSession(mUserObj);
            mUserObj.GL_NACHCycleMast = "NACH_CYCLEMASTER";
            cls_General.SetNACHCycleMastInSession(mUserObj);
            mUserObj.GL_NACHClientPrDataTmp = "NACHTXNPRDATA_TMP";
            cls_General.SetNACHClientPrDataTmpInSession(mUserObj);
            mUserObj.GL_NACHClientTxnMast = "NACHTXNLOG_MASTER";
            cls_General.SetNACHClientTxnMastInSession(mUserObj);
            mUserObj.GL_NACHCorporateMaster = "NACH_CORPORATEMASTER";
            cls_General.SetNACHCorporateMasterInSession(mUserObj);
            mUserObj.GL_NACHUtilityMaster = "NACH_UTILITYMASTER";
            cls_General.SetNACHUtilityMasterInSession(mUserObj);
            mUserObj.GL_USERMaster = "NACH_USERMASTER";
            cls_General.SetUSERMasterInSession(mUserObj);

            mUserObj.GL_SETUP = "NACH_SETUP";
            cls_General.SetSetUPInSession(mUserObj);

            mUserObj.GL_NACHSettlementMaster = "NACH_SETTLEMENTMASTER";
            cls_General.SetNACHSettlementMasterInSession(mUserObj);
            mUserObj.GL_NACHUploadTmpData = "NACHOUTWARD_UPLOADDATA";  //only for batchbalancing
            cls_General.SetNACHUploadTmpDataInSession(mUserObj);
            mUserObj.GL_UnlockFlag = true;
            cls_General.SetUnlockFlagInSession(mUserObj);

            //*******************
            mUserObj.GL_NACHTxnInwardCbsRes = "NACHTXNINWARDCBSRES_" + cls_General.GL_CmpnyCd;
            cls_General.SetNACHTxnInwardCbsResInSession(mUserObj);
            //*******************
            //----------- added by Shailesh ---------------------------
            Session["SessionOutObj"] = SOut;

            CurrentUserList.Add(SOut.UserCode);
            //----------- End -----------------------------------------                               
            this.Doc.RecType = "Company";
            this.Doc.Co_Code = Convert.ToInt32(cls_General.GL_CmpnyCd);
            DataSet Ds = new DataSet();
            CompanyBLL objCompanyBLL = new CompanyBLL();
            Ds = objCompanyBLL.GetData(this.Doc);
            foreach (DataRow Row in Ds.Tables[0].Rows)
            {
                mUserObj.GL_NACHCmpnyCd = Row["NPCI_BANKCODE"].ToString().Trim();
                cls_General.SetNACHCmpnyCdInSession(mUserObj);
                mUserObj.GL_NACHBankName = Row["NAME"].ToString().Trim();
                cls_General.SetNACHBankNameInSession(mUserObj);
                mUserObj.GL_NACHSponsorCd = Row["SPONSOR_BKCODE"].ToString().Trim();
                cls_General.SetNACHSponsorCdInSession(mUserObj);
                mUserObj.GL_NPCIBankCd = Row["NPCI_BANKCODE"].ToString().Trim();
                cls_General.SetNPCIBankCdInSession(mUserObj);
                mUserObj.GL_NPCILoginID = Row["NPCI_LOGINID"].ToString().Trim();
                cls_General.SetNPCILoginIDInSession(mUserObj);
                mUserObj.GL_BankCode = Row["BANK_CODE"].ToString().Trim();
                cls_General.SetBankCodeInSession(mUserObj);

                //17/02/2018
                mUserObj.GL_NPCI_H2HLOGINID = Row["NPCI_H2HLOGINID"].ToString().Trim();
                cls_General.SetNPCIH2HLoginIDInSession(mUserObj);
            }

            this.Doc.RecType = "Utility_Code";
            this.Doc.Co_Code = Convert.ToInt32(cls_General.GL_CmpnyCd);
            this.Doc.Utility_code = ddlUtility.SelectedValue;
            Ds = objCompanyBLL.GetData(this.Doc);

            foreach (DataRow Row in Ds.Tables[0].Rows)
            {

                mUserObj.GL_NACHUtilityID = Row["UTILITY_ID"].ToString().Trim();
                cls_General.SetUtilityIDInSession(mUserObj);
                mUserObj.GL_NACHUtilityCd = Row["UTILITY_CODE"].ToString().Trim();
                cls_General.SetUtilityCDInSession(mUserObj);
                mUserObj.GL_NACHUtilityName = Row["UTILITY_NAME"].ToString().Trim();
                cls_General.SetUtilityNameInSession(mUserObj);
                mUserObj.GL_NACHEcsAccNo = Row["ECS_ACNO"].ToString().Trim();
                cls_General.SetNachEcsAccNoInSession(mUserObj);
                mUserObj.GL_NPCIUserNo = Row["UTILITY_CODE"].ToString().Trim();
                cls_General.SetNPCIUserNoInSession(mUserObj);
                mUserObj.GL_NPCIUserName = Row["NPCI_USERNAME"].ToString().Trim();
                cls_General.SetNPCIUserNameInSession(mUserObj);
                mUserObj.GL_ProductCode = Row["PRODUCT_CODE"].ToString().Trim();
                cls_General.SetNPCIProductCodeInSession(mUserObj);
                mUserObj.GL_MaxAmount = Row["MAX_AMOUNT"].ToString().Trim();
                cls_General.SetMaxAmountInSession(mUserObj);
                mUserObj.GL_Product = Row["PRODUCT_NAME"].ToString().Trim();
                cls_General.SetProductNameInSession(mUserObj);
            }
            this.Doc.RecType = "Setup";
            Ds = objCompanyBLL.GetData(this.Doc);

            foreach (DataRow Row in Ds.Tables[0].Rows)
            {
                mUserObj.GL_NACHScanner = Row["SCANNER"].ToString().Trim();
                cls_General.SetNACHScannerInSession(mUserObj);
                mUserObj.GL_NACHCheckerAuth = Row["CHECKER_AUTHORISE"].ToString().Trim();
                cls_General.SetNACHCheckerAuthInSession(mUserObj);
                mUserObj.GL_NACHCheckerCorrection = Row["CHECKER_CORRECTION"].ToString().Trim();
                cls_General.SetNACHCheckerCorrectionInSession(mUserObj);
                mUserObj.GL_NACHUploadAuth = Row["UPLOAD_AUTHORISE"].ToString().Trim();
                cls_General.SetNACHUploadAuthInSession(mUserObj);
                mUserObj.GL_NACHMMSTimeFrom = Row["MMSTIME_FROM"].ToString().Trim();
                cls_General.SetNACHMMSTimeFromInSession(mUserObj);
                mUserObj.GL_NACHMMSTimeTo = Row["MMSTIME_TO"].ToString().Trim();
                cls_General.SetNACHMMSTimeToInSession(mUserObj);
                mUserObj.GL_NACHTRNTimeFrom = Row["TRNTIME_FROM"].ToString().Trim();
                cls_General.SetNACHTRNTimeFromInSession(mUserObj);
                mUserObj.GL_NACHTRNTimeTo = Row["TRNTIME_TO"].ToString().Trim();
                cls_General.SetNACHTRNTimeToInSession(mUserObj);
                mUserObj.GL_OwnestOutward = Row["OWNESTOUTWARD"].ToString().Trim();
                cls_General.SetOwnestOutwardInSession(mUserObj);
                mUserObj.GL_ScanImagePath = Row["IMAGE_PATH"].ToString().Trim();
                
                cls_General.SetScanImagePathInSession(mUserObj);
                mUserObj.GL_ImagePathOuter = Row["IMAGE_PATH_OUTER"].ToString().Trim();
                
                cls_General.SetImagePathOuterInSession(mUserObj);                
                mUserObj.GL_ImagePathOuterArc = Row["IMAGE_PATH_OUTER_ARC"].ToString().Trim();

                mUserObj.GL_ImagePathTemp = Row["IMAGE_FILE_TEMP"].ToString().Trim();
                cls_General.SetImagePathTempInSession(mUserObj);

                cls_General.SetImagePathOuterArcInSession(mUserObj);
                mUserObj.GL_ImagePathOuterArc = Row["IMAGE_PATH_INWARD_ARC"].ToString().Trim();
                
                cls_General.SetImagePathOuterArcInSession(mUserObj);
                mUserObj.GL_MandateFormat = Row["MANDATE_FORMAT"].ToString().Trim();
                cls_General.SetMandateFormatInSession(mUserObj);
                mUserObj.GL_InwardBatchSize = Row["INWARD_BATCHSIZE"].ToString().Trim();
                cls_General.SetInwardBatchSizeInSession(mUserObj);
                mUserObj.GL_CBSURL = Row["CBS_URL"].ToString().Trim();
                //mUserObj.GL_CBSURL = "https://www.google.co.in/";
               // mUserObj.GL_CBSURL = "http://192.168.100.189/ACH_DR/Login.aspx";
                cls_General.SetCbsUrlInSession(mUserObj);
               
            }

            if (mUserObj.GL_ScanImagePath != "")
            {
                //----------------------Changed--------
                mUserObj.GL_ImagePath = Server.MapPath("~\\Images\\" + cls_General.GL_CmpnyCd) + "\\";
                cls_General.SetImagePathInSession(mUserObj);
                mUserObj.GL_ImagePathShow = "~\\Images\\" + cls_General.GL_CmpnyCd + "\\";
                cls_General.SetImagePathShowInSession(mUserObj);
                if (Directory.Exists(mUserObj.GL_ImagePath) == false)
                {
                    Directory.CreateDirectory(mUserObj.GL_ImagePath);
                }

                mUserObj.GL_InwardImagePath = AppDomain.CurrentDomain.BaseDirectory + "Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\";

                cls_General.SetInwardImagePathInSession(mUserObj);
                if (Directory.Exists(mUserObj.GL_InwardImagePath) == false)
                {
                    Directory.CreateDirectory(mUserObj.GL_InwardImagePath);
                }

            }

            Response.Redirect("~/Home.aspx", false);
        }

        catch (System.Threading.ThreadAbortException lException)
        {
            ucErrorCtrll.Display("Error", lException);
        }
        finally
        {
            //LinkButton lnkbtnHome = (LinkButton)Master.FindControl("lnkHome");
            //lnkbtnHome.Visible = false;
        }

    }

    protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlClient.SelectedItem.Text != "<--Select-->")
            {
                {
                    this.Doc.RecType = "Utility";
                    this.Doc.Client = "7";
                    this.Doc.Category = "HO";
                    this.Doc.Co_Code = Convert.ToInt32(ddlClient.SelectedValue);
                    DataSet dsClient = new DataSet();
                    CompanyBLL objCompanyBLL = new CompanyBLL();
                    dsClient = objCompanyBLL.GetData(this.Doc);
                    ddlUtility.DataSource = dsClient.Tables[0];
                    ddlUtility.DataTextField = "UTILITY_NAME";
                    ddlUtility.DataValueField = "UTILITY_CODE";
                    ddlUtility.DataBind();
                    ddlUtility.Items.Insert(0, "<--Select-->");
                    //ddlUtility.SelectedIndex = 1;
                    ddlUtility.SelectedValue = "UBIN00189000024884";
                    ddlUtility.Items.FindByValue("UBIN00189000024884").Selected = true;
                    btnOK.Focus();
                }
            }
            else
            {
                ddlUtility.Items.Clear();
            }
        }

        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
}