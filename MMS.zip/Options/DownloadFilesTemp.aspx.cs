﻿using NACH_Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options_DownloadFilesTemp : System.Web.UI.Page
{

    UserObj mUserObj = new UserObj();

    cls_General m_cls = new cls_General();
    cls_DBConnection DbObj = new cls_DBConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            { 
                string strFilePath = string.Empty;
                string strModule = Request.QueryString["Module"];
                string filePath = Request.QueryString["FileName"];
                string SettlementDate = Request.QueryString["SettlementDate"];
                mUserObj.GL_Downloadpath = filePath;

                cls_General.SetDownloadpathInSession(mUserObj);
                if (strModule == "Register Mandate")
                {
                    strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/RegisterMandate/" + SettlementDate + "/" + cls_General.GL_Downloadpath;
                }
                else if (strModule == "Approve Mandate")
                {
                    strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/ApproveMandate/" + SettlementDate + "/" + cls_General.GL_Downloadpath;
                }
                //else if (strModule == "ACH Debit Outward")
                //{
                //     strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/RequestPayment/" + DateTime.Now.ToString("ddMMyyyy") + "/" + cls_General.GL_Downloadpath;
                //}
                //else if (strModule == "ACH Debit Inward")
                //{
                //     strFilePath = "~/Data/" + cls_General.GL_CmpnyCd + "/ApprovePayment/" + DateTime.Now.ToString("ddMMyyyy") + "/" + cls_General.GL_Downloadpath;
                //}

                Response.ClearContent();
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                // Response.ContentType = "text/plain";
                Response.AddHeader("Content-Disposition", "attachment;filename=" + cls_General.GL_Downloadpath + ";");
                Response.TransmitFile(System.Web.HttpContext.Current.Server.MapPath(strFilePath));   // TransmitFile &  WriteFile works same way       
                // Response.WriteFile(Server.MapPath(strFilePath));
                Response.Flush();
                // System.IO.File.Delete(Server.MapPath(strFilePath));
                Response.End();
                // Response.Redirect("DownloadFiles.aspx");
            }
            else
            {
                //  Response.Redirect("DownloadFiles.aspx");
            }
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
}