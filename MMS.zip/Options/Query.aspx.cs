﻿using ICSharpCode.SharpZipLib.Zip;
using NACH.BLL;
using NACH.StateClass;
using NACH_Application;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options_Query : System.Web.UI.Page
{
    string m_QueryString;
    static DataTable dt = new DataTable();
    static DataSet ds = new DataSet();
    DataTable dt1 = new DataTable();
    string m_CurrentFile;
    string m_Image, m_batch;
    public static DataSet temp;
    static int counter, End_COunter;
    static string tempType;
    static DataTable History;
    static int index; 
    static bool nxtPrevFlag;

    public QuerySC Doc { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        InitDoc();
        if (!Page.IsPostBack)
        {
            lblAckRejCode.Visible = txtAckRejCode.Visible = false;
            cboSearch_SelectedIndexChanged(null, null);
            History = new DataTable();
            nxtPrevFlag = false;
            chkArchive.Checked = false;
            History.Columns.Add("Criteria");
            History.Columns.Add("Value");
            MandateSRNo();
        }
    }

    public void InitDoc()
    {
        this.Doc = new QuerySC();
    }
    private void MandateSRNo()
    {
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (cboSearch.Text != "<--Select-->")
            {
                errorMsg.Visible = false;
                counter = 0;
                m_QueryString = "";

                if (cboSearch.SelectedItem.Text == "PROCESS_DATE")
                {
                    if (txtFromDate.Text.Trim().Length == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Information", "alert('Please Enter Process Date From');", true);
                        txtFromDate.Focus();
                        return;
                    }
                    if (txtToDate.Text.Trim().Length == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Information", "alert('Please Enter Process Date To');", true);
                        txtToDate.Focus();
                        return;
                    }

                    if (Convert.ToDateTime(txtFromDate.Text).Date > Convert.ToDateTime(txtToDate.Text).Date)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Information", "alert('Process From Date should be Less than To Date');", true);
                        txtFromDate.Focus();
                        return;
                    }
                }
                else if (txtSearchVal.Text != "")
                {
                    this.Doc.m_QueryString = fn_Search(cboSearch.Text, txtSearchVal.Text);
                }
                else
                {
                    errorMsg.Text = "Please Fill All Details";
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Fill The Appropriate Details To Search!');", true);
                    errorMsg.Visible = true;
                    return;
                }
                btnNext.Enabled = btnPrev.Enabled = true;

                QueryBLL mQueryBLL = null;
                mQueryBLL = new QueryBLL();
                UpdateDocObj();
                ds = mQueryBLL.SearchValues(this.Doc);
                temp = ds;
                End_COunter = ds.Tables[0].Rows.Count;
                if (ds.Tables[0].Rows.Count == 1)
                {
                    btnNext.Enabled = btnPrev.Enabled = false;
                    if (nxtPrevFlag != true)
                    {
                        History.Rows.Add(cboSearch.Text, txtSearchVal.Text);
                        if (History.Rows.Count > 0)
                            index = History.Rows.Count - 1;
                    }
                    btnInwardDet.Enabled = true;
                    Fill(counter);
                }
                else if (ds.Tables[0].Rows.Count > 1)
                {
                    btnNext.Enabled = btnPrev.Enabled = true;
                    if (nxtPrevFlag != true)
                    {
                        History.Rows.Add(cboSearch.Text, txtSearchVal.Text);
                        if (History.Rows.Count > 0)
                            index = History.Rows.Count - 1;
                    }
                    btnInwardDet.Enabled = true;
                    Fill(counter);
                    btnNext.Enabled = true;
                }
                else if (ds.Tables[0].Rows.Count == 0)
                {
                    btnNext.Enabled = btnPrev.Enabled = false;
                    if(chkArchive.Checked==true)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No Data Found!');", true);
                        errorMsg.Text = "Data Not Found";
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No Data Found, Please Select Include Archived Option to Search in Archived Data!');", true);
                        errorMsg.Text = "Data Not Found";
                        chkArchive.Focus();
                    }
                    
                    errorMsg.Visible = true;
                    ClearForm(Page.Form.Controls);
                    ds = null;


                    m_CurrentFile = "..\\Images\\" + cls_General.GL_CmpnyCd + "\\0.jpg";
                    imgCheque.ImageUrl = m_CurrentFile;
                }
                nxtPrevFlag = false;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Select the Search Criteria!');", true);
                errorMsg.Text = "Please Fill All Details";
                errorMsg.Visible = true;
                cboSearch.Focus();
            }
        }
        catch (Exception err)
        {
            nxtPrevFlag = false;
            ucErrorCtrll.Display("Error", err);
        }
    }

    public void UpdateDocObj()
    {
        if (cboSearch.SelectedItem.Text == "PROCESS_DATE")
        {
            this.Doc.m_WhrCondtBranch = "";
            this.Doc.FromDate = Convert.ToDateTime(txtFromDate.Text).ToShortDateString();
            this.Doc.ToDate = Convert.ToDateTime(txtToDate.Text).ToShortDateString();
        }
        //this.Doc.Search = cboSearch.SelectedItem.Text;
        if(chkArchive.Checked==true)
        {
            this.Doc.Search = cboSearch.SelectedItem.Text+"|Y";
        }
        else
        {
            this.Doc.Search = cboSearch.SelectedItem.Text+"|N";
        }
        this.Doc.MandateTable = cls_General.GL_MandateData;
        this.Doc.NACHDest = cls_General.GL_NACHDest;
        this.Doc.Co_Code = cls_General.GL_CmpnyCd;
        this.Doc.NACHTxn = cls_General.GL_NACHTxn;
        this.Doc.NPCI_Usercode = txtNPCIUserCode.Text;
        this.Doc.UMRN = txtUMRN.Text;
        this.Doc.NACHDestInw = cls_General.GL_NACHDestInw;
        //this.Doc.zo
    }

    private string fn_Search(string m_SearchCriteria, string m_SearchVal)
    {
        string[] m_SearchCondt;

        string m_SearchString;
        m_SearchString = "";


        m_SearchCondt = m_SearchVal.Trim().ToUpper().ToString().Split(',');


        if (m_SearchVal.Trim().Length > 0 && m_SearchCriteria.Trim().Length > 0)
        {

            for (int i = 0; i < m_SearchCondt.Length; i++)
            {


                if (m_SearchCriteria.Trim().ToUpper() == "MANDATE_SRNO" || m_SearchCriteria.Trim().ToUpper() == "UMRN" || m_SearchCriteria.Trim().ToUpper() == "ACNO" || m_SearchCriteria.Trim().ToUpper() == "CUST_REFNO" || m_SearchCriteria.Trim().ToUpper() == "SCH_REFNO")
                {
                    m_SearchString = m_SearchString + "'" + m_SearchCondt[0] + "',";
                }
                else if (m_SearchCriteria.Trim().ToUpper() == "CUST_NAME")
                {
                    m_SearchString = m_SearchString + " OR CUST_NAME  LIKE '" + m_SearchCondt[0] + "%'";
                }

            }

            if (m_SearchString.Trim().Length > 0)
            {

                if (m_SearchCriteria.Trim().ToUpper() != "CUST_NAME")
                {
                    m_SearchString = m_SearchString.Substring(0, m_SearchString.Trim().Length - 1);

                    m_SearchString = " AND " + m_SearchCriteria.Trim().ToUpper() + " IN (" + m_SearchString + ")";
                }
                else
                {
                    m_SearchString = m_SearchString.Trim().Substring(2);
                    m_SearchString = " AND (" + m_SearchString + ")";
                }

            }
        }

        return m_SearchString;

    }

    public void Fill(int i)
    {
        lblAckRejCode.Visible = txtAckRejCode.Visible = false;
        tempType = ds.Tables[0].Rows[i]["TYPE"].ToString();

        QueryBLL mQueryBLL = null;
        mQueryBLL = new QueryBLL();
        UpdateDocObj();
        this.Doc.Type = ds.Tables[0].Rows[i]["TYPE"].ToString();
        if(chkArchive.Checked==true)
        {
            this.Doc.Type = this.Doc.Type +"|Y";
        }
        else
        {
            this.Doc.Type = this.Doc.Type + "|N";
        }
        this.Doc.IHNO = ds.Tables[0].Rows[i]["IHNO"].ToString();
        this.Doc.Utility_Code = ds.Tables[0].Rows[i]["UTILITY_CODE"].ToString();
        temp = mQueryBLL.FillValues(this.Doc);

        if (temp != null && temp.Tables[0].Rows.Count > 0)
        {
            SetFont(Page.Form.Controls);
            txtUtilityName.Text = temp.Tables[0].Rows[0]["UTILITY_NAME"].ToString();
            txtUtilityCode.Text = temp.Tables[0].Rows[0]["UTILITY_CODE"].ToString();
            if (ds.Tables[0].Rows[i]["TYPE"].ToString() == "O")
            {
                lblCategory.Text = "Outward";
                lblCatgry.Text = "Outward";
                lblCatgry.BackColor = System.Drawing.ColorTranslator.FromHtml("#bac0ff");
                lblCategory.BackColor = System.Drawing.ColorTranslator.FromHtml("#bac0ff");
                lblCategory.Font.Bold = true;

            }
            else
            {
                lblCategory.Text = "Inward";
                lblCatgry.Text = "Inward";
                lblCatgry.BackColor = System.Drawing.ColorTranslator.FromHtml("#bac0ff");
                lblCategory.BackColor = System.Drawing.ColorTranslator.FromHtml("#bac0ff");
                lblCategory.Font.Bold = true;

            }
            if (temp.Tables[0].Rows[0]["COLLECTION_TYPE"].ToString() == "D")
            {
                txtColType.Text = "Debit Amount";
            }
            else
            {
                txtColType.Text = "Up to Maximum Amount";
            }
            txtBatch.Text = temp.Tables[0].Rows[0]["BATCH"].ToString();
            txtIHNO.Text = temp.Tables[0].Rows[0]["IHNO"].ToString();
            txtUMRN.Text = temp.Tables[0].Rows[0]["UMRN"].ToString();
            txtName.Text = temp.Tables[0].Rows[0]["CUST_NAME"].ToString();
            mskEntryDT.Text = temp.Tables[0].Rows[0]["ENTRY1"].ToString() == null || temp.Tables[0].Rows[0]["ENTRY1"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["ENTRY1"].ToString()).Date.ToString("dd/MM/yyyy");
            txtMaker.Text = temp.Tables[0].Rows[0]["USER1"].ToString() == null || temp.Tables[0].Rows[0]["USER1"].ToString() == "" ? "" : fn_UserName(Convert.ToInt32(temp.Tables[0].Rows[0]["USER1"].ToString()));
            mskCheckerDT.Text = temp.Tables[0].Rows[0]["ENTRY2"].ToString() == null || temp.Tables[0].Rows[0]["ENTRY2"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["ENTRY2"].ToString()).Date.ToString("dd/MM/yyyy");
            txtChecker.Text = temp.Tables[0].Rows[0]["USER2"].ToString() == null || temp.Tables[0].Rows[0]["USER2"].ToString() == "" ? "" : fn_UserName(Convert.ToInt32(temp.Tables[0].Rows[0]["USER2"].ToString()));
            mskMandateDT.Text = temp.Tables[0].Rows[0]["MANDATE_DATE"].ToString() == null || temp.Tables[0].Rows[0]["MANDATE_DATE"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["MANDATE_DATE"].ToString()).Date.ToString("dd/MM/yyyy");
            txtMandateID.Text = temp.Tables[0].Rows[0]["MANDATE_ID"].ToString();
            if (temp.Tables[0].Rows[0]["MANDATE_ID"].ToString() == "N")
            {
                txtMandateID.Text = "Create";
            }
            else if (temp.Tables[0].Rows[0]["MANDATE_ID"].ToString() == "U")
            {
                txtMandateID.Text = "Amend";
            }
            else if (temp.Tables[0].Rows[0]["MANDATE_ID"].ToString() == "C")
            {
                txtMandateID.Text = "Cancel";
            }
            txtAcType.Text = temp.Tables[0].Rows[0]["AC_TYPE"].ToString();
            txtAcNo.Text = temp.Tables[0].Rows[0]["ACNO"].ToString();
            txtMicrCode.Text = temp.Tables[0].Rows[0]["BANK_CODE"].ToString();
            txtBank.Text = temp.Tables[0].Rows[0]["BANK"].ToString();
            //  txtBranch.Text = temp.Rows[0]["BRANCH"].ToString();
            txtAmount.Text = temp.Tables[0].Rows[0]["AMOUNT"].ToString();
            txtConsumerNo.Text = temp.Tables[0].Rows[0]["CUST_REFNO"].ToString();
            txtSchemeRefNo.Text = temp.Tables[0].Rows[0]["SCH_REFNO"].ToString();
            if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "MNTH")
            {
                txtFrequency.Text = "MONTHLY";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "QURT")
            {
                txtFrequency.Text = "QUARTERLY";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "MIAN")
            {
                txtFrequency.Text = "HALF YEARLY";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "YEAR")
            {
                txtFrequency.Text = "YEAR";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "BIMN")
            {
                txtFrequency.Text = "BI-MONTHLY";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "OOFF")
            {
                txtFrequency.Text = "as and when presented";
            }
            else if (temp.Tables[0].Rows[0]["FREQUENCY"].ToString() == "ADHO")
            {
                txtFrequency.Text = "as and when presented";
            }
            mskStartDT.Text = temp.Tables[0].Rows[0]["START_DATE"].ToString() == null || temp.Tables[0].Rows[0]["START_DATE"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["START_DATE"].ToString()).Date.ToString("dd/MM/yyyy");
            mskEndDate.Text = temp.Tables[0].Rows[0]["END_DATE"].ToString() == null || temp.Tables[0].Rows[0]["END_DATE"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["END_DATE"].ToString()).Date.ToString("dd/MM/yyyy");
            txtCustID.Text = temp.Tables[0].Rows[0]["CUST_ID"].ToString();
            txtPhone.Text = temp.Tables[0].Rows[0]["TEL_NO"].ToString();
            txtmob.Text = temp.Tables[0].Rows[0]["MOBILE_NO"].ToString();
            txtMail.Text = temp.Tables[0].Rows[0]["MAIL_ID"].ToString();
            // txtUpldUser.Text = temp.Rows[0]["UPLOAD_USER"].ToString() == null || temp.Rows[0]["UPLOAD_USER"].ToString() == "" ? "" : fn_UserName(Convert.ToInt32(temp.Rows[0]["UPLOAD_USER"].ToString()));
            mskUploadDT.Text = temp.Tables[0].Rows[0]["UPLOAD_DATE"].ToString() == null || temp.Tables[0].Rows[0]["UPLOAD_DATE"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["UPLOAD_DATE"].ToString()).Date.ToString("dd/MM/yyyy");
            //txtUpdateUser.Text = temp.Rows[0]["UPDATE_USER"].ToString() == null || temp.Rows[0]["UPDATE_USER"].ToString() == "" ? "" : fn_UserName(Convert.ToInt32(temp.Rows[0]["UPDATE_USER"].ToString()));
            mskUpdateDT.Text = temp.Tables[0].Rows[0]["UPDATE_DATE"].ToString() == null || temp.Tables[0].Rows[0]["UPDATE_DATE"].ToString() == "" ? "" : Convert.ToDateTime(temp.Tables[0].Rows[0]["UPDATE_DATE"].ToString()).Date.ToString("dd/MM/yyyy");
            lstRemark.Items.Clear();
            lstRetReason.Items.Clear();
            lstStatus.Items.Clear();
            //fn_Remak(temp.Tables[0].Rows[0]["PROCESS_CODE"].ToString(), " AND ID='M'", lstRemark);

            //fn_Remak(temp.Tables[0].Rows[0]["RET_CODE"].ToString(), " AND ID='R'", lstRetReason);

            fn_Remak(temp.Tables[0].Rows[0]["PROCESS_CODE"].ToString(), "M", lstRemark);

            fn_Remak(temp.Tables[0].Rows[0]["RET_CODE"].ToString(), "R", lstRetReason);

            if (temp.Tables[0].Rows[0]["LIVE_STATUS"].ToString() == "Y")
            {
                txtLivestatus.Text = "LIVE";
            }
            else if (temp.Tables[0].Rows[0]["LIVE_STATUS"].ToString() == "N")
            {
                txtLivestatus.Text = "NON-LIVE";
            }
            else if (temp.Tables[0].Rows[0]["LIVE_STATUS"].ToString() == "P")
            {
                if (temp.Tables[0].Rows[0]["ACKREJ_CODE"].ToString() != "")
                {
                    lblAckRejCode.Visible = txtAckRejCode.Visible = true;
                    txtLivestatus.Text = "Ack Rejected";
                }
                else
                {
                    txtLivestatus.Text = "PENDING";
                }
            }
            else if (temp.Tables[0].Rows[0]["LIVE_STATUS"].ToString() == "W")
            {
                txtLivestatus.Text = "WRONG";
            }
            else if (temp.Tables[0].Rows[0]["LIVE_STATUS"].ToString() == "I")
            {
                txtLivestatus.Text = "INACTIVE";
            }

            if (temp.Tables[0].Rows[0]["PERIOD"].ToString() == "Y" || (temp.Tables[0].Rows[0]["END_DATE"].ToString().Trim().Length == 0 && temp.Tables[0].Rows[0]["PERIOD"].ToString().Trim().Length == 0))
            {
                chkUntilCancel.Checked = true;
            }
            else
            {
                chkUntilCancel.Checked = false;
            }
            fn_Remak(temp.Tables[0].Rows[0]["STATUS_CODE"].ToString(), "O", lstStatus);
            fn_Remak1(temp.Tables[0].Rows[0]["ACKREJ_CODE"].ToString(), "A", txtAckRejCode);

            if (tempType == "O")
            {

                m_Image = txtIHNO.Text.Trim().PadLeft(8, '0') + ".jpg";

                if (File.Exists(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + temp.Tables[0].Rows[0]["UTILITY_ID"].ToString() + "\\" + txtBatch.Text + "\\" + m_Image))
                {
                    m_CurrentFile = Path.Combine(cls_General.GL_ImagePathOuter + "\\" + cls_General.GL_CmpnyCd + "\\" + temp.Tables[0].Rows[0]["UTILITY_ID"].ToString() + "\\" + txtBatch.Text + "\\" + m_Image);
                }
                else
                {
                    m_CurrentFile = Path.Combine(cls_General.GL_ImagePathOuterArc + "\\" + temp.Tables[0].Rows[0]["UTILITY_ID"].ToString() + "\\" + txtBatch.Text + "\\" + m_Image);
                }
               
                //m_CurrentFile = "..\\Images\\" + cls_General.GL_CmpnyCd + "\\" + temp.Tables[0].Rows[0]["UTILITY_ID"].ToString() + "\\" + txtBatch.Text + "\\" + m_Image;
            }
            else
            {
                m_Image = txtIHNO.Text.Trim().PadLeft(8, '0') + ".jpg";
                if (File.Exists(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + m_Image))
                {
                    m_CurrentFile = Path.Combine(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + m_Image);
                }
                else
                {
                    m_CurrentFile = Path.Combine(cls_General.GL_ImagePathOuter + "\\" + m_Image);
                }
                //m_CurrentFile = @"..\Images\InwardImages\" + cls_General.GL_CmpnyCd + "\\" + m_Image;
            }
            imgCheque.ImageUrl = null;
            if (File.Exists(m_CurrentFile) == true)
                imgCheque.ImageUrl = @"data:image/gif;base64," + Convert.ToBase64String(File.ReadAllBytes(m_CurrentFile));
            //imgCheque.ImageUrl = m_CurrentFile;
        }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        try
        {
            btnPrev.Enabled = true;
            counter++;
            if (counter >= End_COunter - 1)
            {
                btnNext.Enabled = false;
                if (counter == End_COunter - 1)
                {
                    Fill(counter);
                }

            }
            else
            {
                Fill(counter);
            }
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
    protected void btnPrev_Click(object sender, EventArgs e)
    {
        try
        {
            btnNext.Enabled = true;
            counter--;
            if (counter <= 0)
            {
                btnPrev.Enabled = false;
                if (counter == 0)
                {
                    Fill(counter);
                }
            }
            else
            {
                if (counter == 0)
                {
                    btnPrev.Enabled = false;
                }
                Fill(counter);
            }
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }

    private string fn_UserName(int m_UsreCd)
    {
        string m_UserName;
        m_UserName = "";

        //m_Str = "SELECT USER_NAME FROM NACH_USERMASTER WHERE USER_CODE=" + m_UsreCd;

        //dr = DbObj.gl_ExeReader(m_Str);
        this.Doc.RecType = "UserName";
        DataSet mDataset = null;
        mDataset = new DataSet();
        QueryBLL mQueryBLL = null;
        mQueryBLL = new QueryBLL();
        this.Doc.User_Code = Convert.ToString(m_UsreCd);
        mDataset = mQueryBLL.Function(this.Doc);

        if (mDataset != null && mDataset.Tables[0].Rows.Count > 0)
        {
            m_UserName = mDataset.Tables[0].Rows[0]["USER_NAME"].ToString();
        }
        //dr.Close();
        return m_UserName;

    }
    private void fn_Remak(string m_remCode, string m_WhrCondt, ListBox m_cntrl)
    {
        // SqlDataReader drRemak;
        if (m_remCode.Trim().Length > 0)
        {
            string[] m_remark = m_remCode.Split(',');

            m_cntrl.Items.Clear();
            for (int i = 0; i < m_remark.Length; i++)
            {
                //m_Str = "SELECT CODE_DESC FROM " + cls_General.GL_FlagMaster + " WHERE CODE='" + m_remark[0].ToString() + "'" + m_WhrCondt;
                //drRemak = DbObj.gl_ExeReader(m_Str);
                if (m_WhrCondt == "M")
                    this.Doc.RecType = "Remark";
                else if (m_WhrCondt == "R")
                    this.Doc.RecType = "Remarks1";
                else if (m_WhrCondt == "O")
                    this.Doc.RecType = "Status_Code";
                else if (m_WhrCondt == "A")
                    this.Doc.RecType = "ACKRej_Code";
                DataSet mDataset = null;
                mDataset = new DataSet();
                QueryBLL mQueryBLL = null;
                mQueryBLL = new QueryBLL();
                this.Doc.Code = m_remark[0].ToString();
                mDataset = mQueryBLL.Function(this.Doc);
                if (mDataset != null && mDataset.Tables[0].Rows.Count > 0)
                {
                    m_cntrl.Items.Add(mDataset.Tables[0].Rows[0]["CODE_DESC"].ToString());
                }
                //drRemak.Close();
            }
        }
    }
    private void fn_Remak1(string m_remCode, string m_WhrCondt, TextBox m_cntrl)
    {
        //SqlDataReader drRemak;
        if (m_remCode.Trim().Length > 0)
        {
            //m_Str = "SELECT CODE_DESC FROM " + cls_General.GL_FlagMaster + " WHERE CODE='" + m_remCode + "'" + m_WhrCondt;
            //drRemak = DbObj.gl_ExeReader(m_Str);
            this.Doc.RecType = "Remarks1";
            DataSet mDataset = null;
            mDataset = new DataSet();
            QueryBLL mQueryBLL = null;
            mQueryBLL = new QueryBLL();
            this.Doc.Code = m_remCode;
            mDataset = mQueryBLL.Function(this.Doc);
            if (mDataset != null && mDataset.Tables[0].Rows.Count > 0)
            {
                m_cntrl.Text = mDataset.Tables[0].Rows[0]["CODE_DESC"].ToString();
            }
            //drRemak.Close();
        }
    }

    protected void btnInwardDet_Click(object sender, EventArgs e)
    {
        try
        {
            string m_InwType;
            txtNPCIUserCode.Text = txtUtilityCode.Text;
            txtNPCIUserName.Text = txtUtilityName.Text;
            txtTRANUMRN.Text = txtUMRN.Text;
            txtTRANName.Text = txtName.Text;
            txtTranCustRefNo.Text = txtConsumerNo.Text;
            txtTranSchRefNo.Text = txtSchemeRefNo.Text;
            txtTRANFrequency.Text = txtFrequency.Text;
            mskTRANStartDT.Text = mskStartDT.Text;

            mskTRANEndDT.Text = mskEndDate.Text;

            DataSet mDset = null;
            mDset = new DataSet();
            QueryBLL mQueryBLL = null;
            mQueryBLL = new QueryBLL();
            UpdateDocObj();
            this.Doc.Type = tempType;
            mDset = mQueryBLL.InwardDetails(this.Doc);
            //dt1 = DbObj.gl_ExeDataTable(m_Str);
            if (mDset != null && mDset.Tables[0].Rows.Count > 0)
            {
                dgvTransaction.DataSource = mDset;
                dgvTransaction.DataBind();
                lblRocordNotFound.Visible = false;
            }
            else
            {
                lblRocordNotFound.Visible = true;
                dgvTransaction.DataSource = null;
                dgvTransaction.DataBind();
            }
            ImgData.Style.Add("display", "none");
            Trancation.Style.Add("display", "block");
        }
        catch (Exception err)
        {
            ucErrorCtrll.Display("Error", err);
        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        ImgData.Style.Add("display", "block");
        Trancation.Style.Add("display", "none");
    }
    protected void btnCLoseMain_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
        History = new DataTable();
        nxtPrevFlag = false;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearForm(Page.Form.Controls);
        Response.Redirect("~/Home.aspx");
    }
    public void ClearForm(ControlCollection controls)
    {
        foreach (Control c in controls)
        {
            if (c.GetType() == typeof(System.Web.UI.WebControls.TextBox))
            {
                System.Web.UI.WebControls.TextBox t = (System.Web.UI.WebControls.TextBox)c;
                t.Text = String.Empty;
            }

            if (c.GetType() == typeof(System.Web.UI.WebControls.DropDownList))
            {
                System.Web.UI.WebControls.DropDownList t = (System.Web.UI.WebControls.DropDownList)c;
                if (t.ID != "cboSearch")
                    t.Text = String.Empty;
            }
            if (c.GetType() == typeof(System.Web.UI.WebControls.CheckBox))
            {
                System.Web.UI.WebControls.CheckBox t = (System.Web.UI.WebControls.CheckBox)c;
                t.Checked = false;
            }
            if (c.GetType() == typeof(System.Web.UI.WebControls.CheckBoxList))
            {
                System.Web.UI.WebControls.CheckBoxList t = (System.Web.UI.WebControls.CheckBoxList)c;

                for (int i = 0; i < t.Items.Count; i++)
                {
                    t.Items[0].Selected = false;
                }

            }

            if (c.Controls.Count > 0)
                ClearForm(c.Controls);
        }
    }

    public void SetFont(ControlCollection controls)
    {
        foreach (Control c in controls)
        {
            if (c.GetType() == typeof(System.Web.UI.WebControls.TextBox))
            {
                System.Web.UI.WebControls.TextBox t = (System.Web.UI.WebControls.TextBox)c;
                if (t.ID != "txtSearchVal")
                {
                    t.Font.Bold = true;
                }
            }
            if (c.Controls.Count > 0)
                SetFont(c.Controls);
        }
    }
    protected void btnImgPrev_Click(object sender, ImageClickEventArgs e)
    {
        if (History != null)
        {
            if (History.Rows.Count > 0)
            {
                if ((index - 1) >= 0)
                {
                    cboSearch.SelectedValue = History.Rows[index - 1][0].ToString().Trim();
                    txtSearchVal.Text = History.Rows[index - 1][1].ToString().Trim();
                    index = index - 1;
                    nxtPrevFlag = true;
                    btnSearch_Click(null, null);

                }
            }
        }
    }
    protected void btnImgNxt_Click(object sender, ImageClickEventArgs e)
    {
        if (History != null)
        {
            if (History.Rows.Count > 0)
            {
                if ((index + 1) <= History.Rows.Count - 1)
                {
                    cboSearch.SelectedValue = History.Rows[index + 1][0].ToString().Trim();
                    txtSearchVal.Text = History.Rows[index + 1][1].ToString().Trim();
                    index = index + 1;
                    nxtPrevFlag = true;
                    btnSearch_Click(null, null);

                }

            }
        }
    }
    protected void btnDownloadImage_Click(object sender, EventArgs e)
    {
        if (lblCategory.Text.ToUpper().Trim() == "INWARD")
        {
            string folderPath, zipFilePath;
            zipFilePath = "";
            folderPath = "";

            folderPath = cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\";



            zipFilePath = cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\" + txtIHNO.Text + ".zip";

            //folderPath = Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\");
            //zipFilePath = Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\") + txtIHNO.Text + ".zip";

            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            if (File.Exists(zipFilePath))
            {
                File.Delete(zipFilePath);
            }
            using (ZipFile zipFile = ZipFile.Create(zipFilePath))
            {
                zipFile.NameTransform = new ZipNameTransform(folderPath);
                zipFile.BeginUpdate();
                zipFile.Add(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".jpg", Path.GetFileName(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".jpg"));
                zipFile.Add(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".tif", Path.GetFileName(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".tif"));

                //zipFile.Add(Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".jpg"), Path.GetFileName(Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".jpg")));
                //zipFile.Add(Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".tif"), Path.GetFileName(Server.MapPath("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + txtIHNO.Text.ToString().PadLeft(8, '0') + ".tif")));
                zipFile.CommitUpdate();
                zipFile.Close();
                //}
                //Response.Redirect(cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\" + txtIHNO.Text.Trim() + ".zip");
                //Response.Redirect("~\\Images\\InwardImages\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\" + txtIHNO.Text + ".zip");

                string path = cls_General.GL_ImagePathOuter + "\\" + "InwardImages" + "\\" + cls_General.GL_CmpnyCd + "\\" + DateTime.Now.ToShortDateString() + "\\" + txtIHNO.Text.Trim() + ".zip";
                if (File.Exists(path))
                {
                    byte[] bts = System.IO.File.ReadAllBytes(path);
                    MemoryStream ms = new MemoryStream(bts);
                    Response.Clear();
                    Response.AddHeader("Content-Disposition", "attachment;filename=\"" + Path.GetFileName(path) + "\"");
                    Response.ContentType = "application/octet-stream";
                    //Response.ContentType = "application/zip";
                    Response.TransmitFile(path);
                    Response.Flush();
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                    Response.End();
                }
            }
        }
    }

    protected void dgvTransaction_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        btnInwardDet_Click(null, null);
        dgvTransaction.PageIndex = e.NewPageIndex;
        dgvTransaction.DataBind();
    }
    protected void cboSearch_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (cboSearch.SelectedValue.ToUpper() == "PROCESS_DATE")
        {
            tbFrmTO.Visible = true;
            tbldll.Visible = false;
        }
        else
        {
            txtSearchVal.Text = "";
            ClearForm(Page.Form.Controls);
            tbFrmTO.Visible = false;
            tbldll.Visible = true;
        }
    }
}